import { useEffect, useState } from 'react';

/**
 * Efekt „pisania” odpowiedzi AI.
 *
 * Streaming przysyła tekst paczkami (po kilka–kilkanaście słów). Ten hook
 * wygładza to: odsłania znaki płynnie, przyspieszając, gdy zaległość rośnie,
 * więc nigdy nie zostaje daleko w tyle za strumieniem.
 *
 * @param {string} target  pełny tekst otrzymany do tej pory
 * @param {boolean} enabled  false → od razu cały tekst (np. wynik z historii)
 */
export function useTypewriter(target, enabled = true) {
  const [shown, setShown] = useState(0);
  const goal = target.length;

  useEffect(() => {
    if (!enabled) return undefined;
    const timer = setInterval(() => {
      setShown((current) => {
        // Nowy, krótszy tekst (np. ponowna analiza) — zaczynamy od początku.
        if (current >= goal) return goal;
        const backlog = goal - current;
        return current + Math.max(2, Math.ceil(backlog / 12));
      });
    }, 16);
    return () => clearInterval(timer);
  }, [enabled, goal]);

  const length = enabled ? Math.min(shown, goal) : goal;
  return { text: target.slice(0, length), done: length >= goal };
}
