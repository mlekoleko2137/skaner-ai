import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { ScrollView, StyleSheet, View } from 'react-native';
import { Button, Text, useTheme } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import FadeIn from '../components/FadeIn';
import Logo from '../components/Logo';
import { markWelcomeSeen } from '../services/settingsService';

const FEATURES = [
  { icon: 'text-recognition', title: 'Tekst rozpoznawany na telefonie', text: 'Do AI trafia sam tekst, więc jest szybciej.' },
  { icon: 'file-document-multiple-outline', title: 'Rozpoznaje typ dokumentu', text: 'Sprawdzian, kartkówka, notatka czy praca domowa.' },
  { icon: 'lightning-bolt-outline', title: 'Odpowiedź na bieżąco', text: 'Tekst pojawia się słowo po słowie.' },
  { icon: 'history', title: 'Historia skanów', text: 'Wszystkie wyniki zostają na telefonie.' },
];

/** Ekran powitalny — pokazywany przy pierwszym uruchomieniu. */
export default function WelcomeScreen({ navigation }) {
  const theme = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.custom;

  const start = async () => {
    await markWelcomeSeen().catch(() => {});
    navigation.reset({ index: 0, routes: [{ name: 'Home' }] });
  };

  return (
    <View style={[styles.root, { backgroundColor: c.background, paddingBottom: insets.bottom + 16 }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: insets.top + 48 }]}>
        <FadeIn>
          <Logo size={64} />
        </FadeIn>
        <FadeIn delay={100}>
          <Text variant="displaySmall" style={styles.title}>
            Skaner Dokumentów AI
          </Text>
        </FadeIn>
        <FadeIn delay={180}>
          <Text variant="bodyLarge" style={{ color: c.muted, lineHeight: 24 }}>
            Zrób zdjęcie sprawdzianu, notatki albo pracy domowej. Rozpoznam dokument i pomogę go zrozumieć
            i rozwiązać.
          </Text>
        </FadeIn>
        <View style={styles.features}>
          {FEATURES.map((f, i) => (
            <FadeIn key={f.icon} delay={260 + i * 70}>
              <View style={styles.feature}>
                <View style={[styles.featureIcon, { backgroundColor: c.surfaceAlt }]}>
                  <MaterialCommunityIcons name={f.icon} size={22} color={c.text} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text variant="titleSmall">{f.title}</Text>
                  <Text variant="bodySmall" style={{ color: c.muted, marginTop: 2 }}>
                    {f.text}
                  </Text>
                </View>
              </View>
            </FadeIn>
          ))}
        </View>
      </ScrollView>
      <FadeIn delay={600} style={styles.footer}>
        <Button mode="contained" onPress={start} contentStyle={styles.buttonContent} labelStyle={styles.buttonLabel}>
          Zaczynamy
        </Button>
      </FadeIn>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 24, paddingBottom: 24 },
  title: { marginTop: 28, marginBottom: 12, letterSpacing: -0.5 },
  features: { marginTop: 32, gap: 18 },
  feature: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  featureIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  footer: { paddingHorizontal: 24 },
  buttonContent: { height: 56 },
  buttonLabel: { fontSize: 16 },
});
