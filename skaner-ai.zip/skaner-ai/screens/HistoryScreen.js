import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback, useLayoutEffect, useState } from 'react';
import { Alert, FlatList, StyleSheet, View } from 'react-native';
import { IconButton, Text, useTheme } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import HistoryItem from '../components/HistoryItem';
import { clearHistory, deleteScan, getScans } from '../services/historyService';

/** Historia skanów: dotknięcie otwiera wynik, przytrzymanie usuwa. */
export default function HistoryScreen({ navigation }) {
  const theme = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.custom;
  const [scans, setScans] = useState(null);

  const load = useCallback(() => {
    getScans().then(setScans);
  }, []);

  useFocusEffect(load);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () =>
        scans?.length ? (
          <IconButton
            icon="delete-sweep-outline"
            accessibilityLabel="Wyczyść historię"
            onPress={() =>
              Alert.alert('Wyczyścić historię?', 'Usunie wszystkie zapisane skany i odpowiedzi.', [
                { text: 'Anuluj', style: 'cancel' },
                {
                  text: 'Wyczyść',
                  style: 'destructive',
                  onPress: async () => {
                    await clearHistory();
                    load();
                  },
                },
              ])
            }
          />
        ) : null,
    });
  }, [navigation, scans, load]);

  const confirmDelete = (scan) =>
    Alert.alert('Usunąć skan?', undefined, [
      { text: 'Anuluj', style: 'cancel' },
      {
        text: 'Usuń',
        style: 'destructive',
        onPress: async () => {
          await deleteScan(scan.id);
          load();
        },
      },
    ]);

  if (scans && scans.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: c.background }]}>
        <MaterialCommunityIcons name="history" size={40} color={c.muted} />
        <Text variant="titleMedium" style={{ marginTop: 12 }}>
          Brak skanów
        </Text>
        <Text variant="bodyMedium" style={{ color: c.muted, marginTop: 4, textAlign: 'center' }}>
          Tu pojawią się wszystkie zeskanowane dokumenty.
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: c.background }}
      contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 16 }}
      data={scans || []}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <HistoryItem
          scan={item}
          onPress={() => navigation.navigate('Result', { scanId: item.id })}
          onLongPress={() => confirmDelete(item)}
        />
      )}
      ListFooterComponent={
        scans?.length ? (
          <Text variant="bodySmall" style={{ color: c.muted, textAlign: 'center', marginTop: 16 }}>
            Przytrzymaj skan, aby go usunąć.
          </Text>
        ) : null
      }
    />
  );
}

const styles = StyleSheet.create({
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
});
