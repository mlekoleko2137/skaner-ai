import { useFocusEffect } from '@react-navigation/native';
import { useCallback, useLayoutEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, View } from 'react-native';
import { Button, Card, IconButton, Text, useTheme } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import ActionCard from '../components/ActionCard';
import FadeIn from '../components/FadeIn';
import HistoryItem from '../components/HistoryItem';
import Logo from '../components/Logo';
import { getScans } from '../services/historyService';
import { getApiConfig } from '../services/settingsService';
import { pickFromLibrary, takePhoto } from '../utils/pickImage';

/** Ekran główny: „Zrób zdjęcie”, „Wybierz z galerii”, ostatnie skany. */
export default function HomeScreen({ navigation }) {
  const theme = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.custom;
  const [recent, setRecent] = useState([]);
  const [configured, setConfigured] = useState(true);
  const [busy, setBusy] = useState(false);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => <Logo size={32} />,
      headerRight: () => (
        <View style={styles.headerActions}>
          <IconButton icon="history" accessibilityLabel="Historia" onPress={() => navigation.navigate('History')} />
          <IconButton icon="cog-outline" accessibilityLabel="Ustawienia" onPress={() => navigation.navigate('Settings')} />
        </View>
      ),
    });
  }, [navigation]);

  // Odświeżamy po powrocie z innych ekranów (nowy skan, zmiana klucza).
  useFocusEffect(
    useCallback(() => {
      let active = true;
      getScans().then((s) => active && setRecent(s.slice(0, 3)));
      getApiConfig().then((cfg) => active && setConfigured(cfg.mode !== 'missing'));
      return () => {
        active = false;
      };
    }, []),
  );

  const start = async (picker) => {
    if (busy) return;
    setBusy(true);
    try {
      const asset = await picker();
      if (asset) navigation.navigate('Result', { imageUri: asset.uri, width: asset.width, height: asset.height });
    } catch (e) {
      Alert.alert('Nie udało się', e.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView
      style={{ backgroundColor: c.background }}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 24 }]}
    >
      <FadeIn>
        <Text variant="headlineMedium" style={{ color: c.muted }}>
          Cześć!
        </Text>
        <Text variant="headlineMedium" style={styles.headline}>
          Co dziś skanujemy?
        </Text>
      </FadeIn>

      {!configured ? (
        <FadeIn delay={60}>
          <Card mode="outlined" style={styles.banner}>
            <Card.Title
              title="Dodaj klucz API Claude"
              subtitle="Bez niego nie przeanalizuję dokumentu."
              left={(props) => <IconButton {...props} icon="key-outline" />}
            />
            <Card.Actions>
              <Button mode="contained" onPress={() => navigation.navigate('Settings')}>
                Przejdź do ustawień
              </Button>
            </Card.Actions>
          </Card>
        </FadeIn>
      ) : null}

      <View style={styles.actions}>
        <FadeIn delay={120}>
          <ActionCard
            primary
            icon="camera-outline"
            title="Zrób zdjęcie"
            subtitle="Sfotografuj kartkę, zeszyt lub tablicę"
            disabled={busy}
            onPress={() => start(takePhoto)}
          />
        </FadeIn>
        <FadeIn delay={180}>
          <ActionCard
            icon="image-multiple-outline"
            title="Wybierz z galerii"
            subtitle="Użyj zapisanego zdjęcia"
            disabled={busy}
            onPress={() => start(pickFromLibrary)}
          />
        </FadeIn>
      </View>

      {recent.length > 0 ? (
        <FadeIn delay={240}>
          <View style={styles.sectionHeader}>
            <Text variant="titleMedium">Ostatnie skany</Text>
            <Button compact onPress={() => navigation.navigate('History')}>
              Wszystkie
            </Button>
          </View>
          {recent.map((scan) => (
            <HistoryItem
              key={scan.id}
              scan={scan}
              onPress={() => navigation.navigate('Result', { scanId: scan.id })}
            />
          ))}
        </FadeIn>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 20, paddingTop: 12 },
  headerActions: { flexDirection: 'row', marginRight: -8 },
  headline: { marginBottom: 24, letterSpacing: -0.5 },
  banner: { marginBottom: 20, borderRadius: 20 },
  actions: { gap: 12 },
  sectionHeader: {
    marginTop: 32,
    marginBottom: 4,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});
