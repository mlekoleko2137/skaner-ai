import Constants from 'expo-constants';
import { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from 'react-native';
import { Button, Divider, HelperText, RadioButton, Text, TextInput, useTheme } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { clearHistory } from '../services/historyService';
import { isOcrAvailable } from '../services/ocrService';
import { MODELS, getApiConfig, getModel, getStoredApiKey, saveApiKey, setModel } from '../services/settingsService';

const KEY_SOURCE_LABEL = {
  app: 'Zapisany w aplikacji (bezpieczny magazyn telefonu)',
  env: 'Z pliku .env (wkompilowany w aplikację — tylko do testów)',
  proxy: 'Serwer pośredniczący — klucz nie jest w aplikacji',
  none: 'Brak — dodaj klucz poniżej',
};

async function loadSettings() {
  const [stored, config, m] = await Promise.all([getStoredApiKey(), getApiConfig(), getModel()]);
  return { stored, config, m };
}

/** Ustawienia: klucz API, model, OCR, czyszczenie danych. */
export default function SettingsScreen() {
  const theme = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.custom;
  const [keyInput, setKeyInput] = useState('');
  const [hasStoredKey, setHasStoredKey] = useState(false);
  const [keySource, setKeySource] = useState('none');
  const [model, setModelState] = useState(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  const apply = ({ stored, config, m }) => {
    setHasStoredKey(!!stored);
    setKeySource(config.keySource);
    setModelState(m);
  };
  const refresh = () => loadSettings().then(apply);

  useEffect(() => {
    let active = true;
    loadSettings().then((data) => active && apply(data));
    return () => {
      active = false;
    };
  }, []);

  const keyLooksValid = /^sk-ant-[\w-]{20,}$/.test(keyInput.trim());

  const save = async () => {
    setSaving(true);
    try {
      await saveApiKey(keyInput);
      setKeyInput('');
      setMessage('Klucz zapisany.');
      await refresh();
    } catch (e) {
      setMessage(`Nie udało się zapisać klucza: ${e.message || e}`);
    } finally {
      setSaving(false);
    }
  };

  const removeKey = async () => {
    await saveApiKey('');
    setMessage('Klucz usunięty z aplikacji.');
    await refresh();
  };

  const changeModel = async (id) => {
    setModelState(id);
    await setModel(id);
  };

  const ocr = isOcrAvailable();

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        style={{ backgroundColor: c.background }}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 32 }]}
        keyboardShouldPersistTaps="handled"
      >
        <Text variant="titleMedium">Klucz API Claude</Text>
        <Text variant="bodySmall" style={[styles.muted, { color: c.muted }]}>
          Aktualnie: {KEY_SOURCE_LABEL[keySource]}
        </Text>
        <TextInput
          mode="outlined"
          label="Wklej klucz (sk-ant-…)"
          accessibilityLabel="Klucz API Claude"
          testID="api-key-input"
          value={keyInput}
          onChangeText={setKeyInput}
          secureTextEntry
          autoCapitalize="none"
          autoCorrect={false}
          style={styles.input}
        />
        <HelperText type={keyInput && !keyLooksValid ? 'error' : 'info'} visible>
          {keyInput && !keyLooksValid
            ? 'To nie wygląda na klucz Claude (powinien zaczynać się od „sk-ant-”).'
            : 'Klucz utworzysz w Claude Console (platform.claude.com) → API Keys.'}
        </HelperText>
        <View style={styles.row}>
          <Button mode="contained" onPress={save} loading={saving} disabled={!keyLooksValid || saving}>
            Zapisz klucz
          </Button>
          {hasStoredKey ? <Button onPress={removeKey}>Usuń klucz</Button> : null}
        </View>
        {message ? (
          <Text variant="bodySmall" style={{ marginTop: 8 }}>
            {message}
          </Text>
        ) : null}

        <Divider style={styles.divider} />

        <Text variant="titleMedium">Model</Text>
        <RadioButton.Group onValueChange={changeModel} value={model}>
          {MODELS.map((m) => (
            <RadioButton.Item
              key={m.id}
              value={m.id}
              label={`${m.label} — ${m.hint}`}
              labelVariant="bodyMedium"
              style={styles.radio}
            />
          ))}
        </RadioButton.Group>

        <Divider style={styles.divider} />

        <Text variant="titleMedium">Rozpoznawanie tekstu (OCR)</Text>
        <Text variant="bodyMedium" style={[styles.muted, { color: c.muted }]}>
          {ocr
            ? 'Google ML Kit działa na tym telefonie: do Claude wysyłany jest sam tekst, a zdjęcie tylko wtedy, gdy tekst jest nieczytelny.'
            : 'ML Kit nie jest dostępny w Expo Go — do Claude wysyłane jest zdjęcie. OCR na telefonie zadziała w wersji zbudowanej przez EAS (development build lub TestFlight).'}
        </Text>

        <Divider style={styles.divider} />

        <Text variant="titleMedium">Dane</Text>
        <Button
          mode="outlined"
          icon="delete-outline"
          style={styles.dataButton}
          onPress={() =>
            Alert.alert('Wyczyścić dane?', 'Usunie historię skanów i zapisane wyniki.', [
              { text: 'Anuluj', style: 'cancel' },
              {
                text: 'Wyczyść',
                style: 'destructive',
                onPress: async () => {
                  await clearHistory();
                  setMessage('Historia wyczyszczona.');
                },
              },
            ])
          }
        >
          Wyczyść historię i pamięć podręczną
        </Button>

        <Text variant="bodySmall" style={[styles.version, { color: c.muted }]}>
          Skaner Dokumentów AI {Constants.expoConfig?.version ?? ''}
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20 },
  muted: { marginTop: 4, lineHeight: 20 },
  input: { marginTop: 12 },
  row: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  divider: { marginVertical: 24 },
  radio: { paddingHorizontal: 0 },
  dataButton: { marginTop: 12, alignSelf: 'flex-start' },
  version: { marginTop: 32, textAlign: 'center' },
});
