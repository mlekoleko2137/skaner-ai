import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Image, Modal, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { ActivityIndicator, Button, Snackbar, Text, useTheme } from 'react-native-paper';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import ClassificationBadges from '../components/ClassificationBadges';
import FadeIn from '../components/FadeIn';
import Logo from '../components/Logo';
import Markdown from '../components/Markdown';
import { useTypewriter } from '../hooks/useTypewriter';
import { getScan } from '../services/historyService';
import { scanDocument } from '../services/scanService';
import { takePhoto } from '../utils/pickImage';

const STAGE_LABELS = {
  preparing: 'Przygotowuję zdjęcie…',
  cache: 'Wczytuję zapisany wynik…',
  ocr: 'Rozpoznaję tekst na telefonie…',
  'sending-text': 'Analizuję tekst…',
  'sending-image': 'Analizuję zdjęcie…',
};

/**
 * Ekran wyniku. Parametry nawigacji:
 * - { imageUri, width, height } — nowy skan,
 * - { scanId } — wynik z historii (bez ponownego wysyłania).
 */
export default function ResultScreen({ route, navigation }) {
  const theme = useTheme();
  const insets = useSafeAreaInsets();
  const c = theme.custom;
  const { imageUri, width, height, scanId } = route.params || {};

  const [stage, setStage] = useState(imageUri && !scanId ? 'preparing' : null);
  const [live, setLive] = useState(null); // odpowiedź w trakcie streamingu
  const [scan, setScan] = useState(null); // zapisany wynik
  const [error, setError] = useState(null);
  const [streaming, setStreaming] = useState(!!imageUri && !scanId);
  const [preview, setPreview] = useState(false);
  const [snack, setSnack] = useState('');
  const abortRef = useRef(null);

  /** Wykonuje skan; stan zmienia wyłącznie w odpowiedzi na zdarzenia skanu. */
  const execute = useCallback(
    ({ forceImage = false } = {}) => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;
      const alive = () => !controller.signal.aborted;
      scanDocument({
        imageUri,
        width,
        height,
        forceImage,
        signal: controller.signal,
        onStage: (s) => alive() && setStage(s),
        onUpdate: (parsed) => alive() && setLive(parsed),
      })
        .then((result) => {
          if (!alive()) return;
          setScan(result);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
        })
        .catch((e) => {
          if (alive() && e?.type !== 'aborted') setError(e?.message || String(e));
        })
        .finally(() => {
          if (alive()) {
            setStreaming(false);
            setStage(null);
          }
        });
    },
    [imageUri, width, height],
  );

  /** Ponowienie z przycisku: czyścimy ekran i startujemy od nowa. */
  const retry = (options) => {
    setError(null);
    setScan(null);
    setLive(null);
    setStreaming(true);
    execute(options);
  };

  useEffect(() => {
    if (scanId) {
      getScan(scanId).then((s) => (s ? setScan({ ...s, fromHistory: true }) : setError('Nie znaleziono skanu.')));
    } else if (imageUri) {
      execute();
    }
    return () => abortRef.current?.abort();
  }, [scanId, imageUri, execute]);

  const shownImage = scan?.imageUri || imageUri;
  const classification = scan?.classification || live?.classification || null;
  const answer = scan?.answer ?? live?.answer ?? '';
  const source = scan?.source || live?.source;
  const animate = !(scan?.fromHistory || scan?.fromCache);
  const typed = useTypewriter(answer, animate);
  const typing = streaming || !typed.done;

  const copy = async () => {
    await Clipboard.setStringAsync(answer);
    setSnack('Skopiowano odpowiedź');
  };

  const newPhoto = async () => {
    try {
      const asset = await takePhoto();
      if (asset) navigation.replace('Result', { imageUri: asset.uri, width: asset.width, height: asset.height });
    } catch (e) {
      setSnack(e.message || String(e));
    }
  };

  return (
    <View style={[styles.root, { backgroundColor: c.background }]}>
      <ScrollView contentContainerStyle={styles.content}>
        {shownImage ? (
          <FadeIn style={styles.userRow}>
            <Pressable onPress={() => setPreview(true)} accessibilityLabel="Powiększ zdjęcie">
              <Image
                source={{ uri: shownImage }}
                style={[styles.userImage, { backgroundColor: c.surfaceAlt, borderColor: c.border }]}
                resizeMode="cover"
              />
            </Pressable>
          </FadeIn>
        ) : null}

        <FadeIn delay={120} style={styles.aiRow}>
          <Logo size={32} />
          <View style={styles.aiContent}>
            {error ? (
              <View style={[styles.errorBox, { borderColor: c.accent }]}>
                <Text variant="titleSmall" style={{ marginBottom: 4 }}>
                  Coś poszło nie tak
                </Text>
                <Text variant="bodyMedium" style={{ color: c.muted, marginBottom: 12 }}>
                  {error}
                </Text>
                {imageUri ? (
                  <View style={styles.errorActions}>
                    <Button mode="contained" onPress={() => retry()}>
                      Spróbuj ponownie
                    </Button>
                    {/^Brak klucza|klucz API/.test(error) ? (
                      <Button onPress={() => navigation.navigate('Settings')}>Ustawienia</Button>
                    ) : null}
                  </View>
                ) : null}
              </View>
            ) : (
              <>
                <ClassificationBadges
                  classification={classification}
                  source={answer ? source : null}
                  fromCache={scan?.fromCache}
                />
                {!answer && stage ? (
                  <View style={styles.stage}>
                    <ActivityIndicator size="small" />
                    <Text variant="bodyMedium" style={{ color: c.muted, marginLeft: 10 }}>
                      {STAGE_LABELS[stage] || 'Pracuję…'}
                    </Text>
                  </View>
                ) : null}
                {answer ? <Markdown text={typed.text} cursor={typing} /> : null}
                {scan && !streaming ? <ResultMeta scan={scan} color={c.muted} /> : null}
              </>
            )}
          </View>
        </FadeIn>
      </ScrollView>

      {imageUri || scan ? (
        <View style={[styles.bottomBar, { borderColor: c.border, paddingBottom: insets.bottom + 10 }]}>
          {streaming ? (
            <Button
              mode="outlined"
              icon="stop"
              style={styles.flex}
              onPress={() => {
                abortRef.current?.abort();
                setStreaming(false);
                setStage(null);
                if (!answer) setError('Analiza przerwana.');
              }}
            >
              Zatrzymaj
            </Button>
          ) : (
            <>
              <Button mode="outlined" icon="content-copy" disabled={!answer} onPress={copy}>
                Kopiuj
              </Button>
              {imageUri && scan?.source === 'ocr' ? (
                <Button mode="outlined" icon="image-search-outline" onPress={() => retry({ forceImage: true })}>
                  Ze zdjęcia
                </Button>
              ) : null}
              <Button mode="contained" icon="camera-outline" style={styles.flex} onPress={newPhoto}>
                Nowe zdjęcie
              </Button>
            </>
          )}
        </View>
      ) : null}

      <Modal visible={preview} transparent animationType="fade" onRequestClose={() => setPreview(false)}>
        <Pressable style={styles.modal} onPress={() => setPreview(false)}>
          <Image source={{ uri: shownImage }} style={styles.modalImage} resizeMode="contain" />
        </Pressable>
      </Modal>

      <Snackbar visible={!!snack} onDismiss={() => setSnack('')} duration={2000}>
        {snack}
      </Snackbar>
    </View>
  );
}

function ResultMeta({ scan, color }) {
  const parts = [];
  if (scan.source === 'ocr') parts.push(`OCR na telefonie (${scan.ocrMs ?? 0} ms) → tekst do Claude`);
  else parts.push(scan.ocrAvailable ? 'Tekst nieczytelny — wysłano zdjęcie' : 'Wysłano zdjęcie (OCR niedostępny)');
  if (scan.model) parts.push(scan.model);
  const cached = scan.usage?.cache_read_input_tokens;
  if (cached) parts.push(`instrukcje z cache: ${cached} tok.`);
  return (
    <View style={styles.meta}>
      {scan.truncated ? (
        <Text variant="bodySmall" style={{ color, marginBottom: 4 }}>
          Odpowiedź została ucięta (limit długości). Zrób zdjęcie mniejszego fragmentu.
        </Text>
      ) : null}
      <Text variant="bodySmall" style={{ color }}>
        {parts.join(' · ')}
      </Text>
      <Text variant="bodySmall" style={{ color, marginTop: 2 }}>
        AI może się mylić — sprawdź odpowiedzi.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { padding: 16, paddingBottom: 32 },
  userRow: { alignItems: 'flex-end', marginBottom: 20 },
  userImage: {
    width: 180,
    height: 240,
    borderRadius: 20,
    borderBottomRightRadius: 6,
    borderWidth: StyleSheet.hairlineWidth,
  },
  aiRow: { flexDirection: 'row', alignItems: 'flex-start' },
  aiContent: { flex: 1, marginLeft: 12 },
  stage: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  errorBox: { borderWidth: 1, borderRadius: 16, padding: 14 },
  errorActions: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  meta: { marginTop: 18 },
  bottomBar: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    paddingTop: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  flex: { flex: 1 },
  modal: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', justifyContent: 'center' },
  modalImage: { width: '100%', height: '100%' },
});
