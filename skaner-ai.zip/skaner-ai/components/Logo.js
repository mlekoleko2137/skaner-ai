import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { View } from 'react-native';
import { useTheme } from 'react-native-paper';

/** Monochromatyczne logo / awatar asystenta. */
export default function Logo({ size = 40 }) {
  const theme = useTheme();
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: theme.custom.text,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <MaterialCommunityIcons name="creation" size={size * 0.55} color={theme.custom.background} />
    </View>
  );
}
