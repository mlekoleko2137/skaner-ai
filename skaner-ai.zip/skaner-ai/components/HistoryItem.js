import { Image, Pressable, StyleSheet, View } from 'react-native';
import { Text, useTheme } from 'react-native-paper';

import { DOCUMENT_TYPES } from '../services/prompts';

/** Wiersz historii: miniatura, typ dokumentu, przedmiot, data. */
export default function HistoryItem({ scan, onPress, onLongPress }) {
  const theme = useTheme();
  const c = theme.custom;
  const type = scan.classification?.typeLabel || DOCUMENT_TYPES.inne;
  const subject = scan.classification?.subject;

  return (
    <Pressable
      onPress={onPress}
      onLongPress={onLongPress}
      accessibilityRole="button"
      style={({ pressed }) => [styles.row, { borderColor: c.border, opacity: pressed ? 0.7 : 1 }]}
    >
      <Image source={{ uri: scan.imageUri }} style={[styles.thumb, { backgroundColor: c.surfaceAlt }]} />
      <View style={styles.texts}>
        <Text variant="titleSmall" numberOfLines={1}>
          {type}
          {subject && subject !== 'nieznany' ? ` · ${subject}` : ''}
        </Text>
        <Text variant="bodySmall" numberOfLines={2} style={{ color: c.muted, marginTop: 2 }}>
          {firstLine(scan.answer)}
        </Text>
        <Text variant="labelSmall" style={{ color: c.muted, marginTop: 4 }}>
          {formatDate(scan.createdAt)}
        </Text>
      </View>
    </Pressable>
  );
}

function firstLine(answer) {
  const line = (answer || '')
    .split('\n')
    .map((l) => l.replace(/^#+\s*|\*\*/g, '').trim())
    .find((l) => l.length > 0);
  return line || '';
}

/** dd.mm.rrrr, gg:mm — bez zależności od Intl (eksport do testów). */
export function formatDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getDate())}.${p(d.getMonth() + 1)}.${d.getFullYear()}, ${p(d.getHours())}:${p(d.getMinutes())}`;
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  thumb: { width: 56, height: 72, borderRadius: 10, marginRight: 14 },
  texts: { flex: 1 },
});
