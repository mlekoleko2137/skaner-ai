import { StyleSheet, View } from 'react-native';
import { Divider, Text, useTheme } from 'react-native-paper';

/**
 * Lekki renderer Markdown dla odpowiedzi Claude: nagłówki (#, ##, ###),
 * listy (-, *, 1.), **pogrubienie**, *kursywa*, `kod`, separator (---).
 * Bez zewnętrznych zależności — działa w Expo Go.
 */
export default function Markdown({ text, cursor = false }) {
  const theme = useTheme();
  const lines = (text || '').replace(/\r\n?/g, '\n').split('\n');
  const blocks = [];

  lines.forEach((line, index) => {
    const isLast = index === lines.length - 1;
    const tail = cursor && isLast ? <Text style={{ color: theme.colors.onSurfaceVariant }}>▍</Text> : null;
    const key = `l${index}`;
    const trimmed = line.trim();

    if (!trimmed) {
      blocks.push(<View key={key} style={styles.gap}>{tail}</View>);
      return;
    }
    if (/^-{3,}$/.test(trimmed) || /^\*{3,}$/.test(trimmed)) {
      blocks.push(<Divider key={key} style={styles.divider} />);
      return;
    }
    const heading = /^(#{1,3})\s+(.*)$/.exec(trimmed);
    if (heading) {
      const level = heading[1].length;
      const variant = level === 1 ? 'titleLarge' : level === 2 ? 'titleMedium' : 'titleSmall';
      blocks.push(
        <Text key={key} variant={variant} style={[styles.heading, level === 2 && styles.h2]}>
          {renderInline(heading[2], theme)}
          {tail}
        </Text>,
      );
      return;
    }
    const bullet = /^[-*•]\s+(.*)$/.exec(trimmed);
    const numbered = /^(\d{1,3})[.)]\s+(.*)$/.exec(trimmed);
    if (bullet || numbered) {
      const marker = bullet ? '•' : `${numbered[1]}.`;
      const content = bullet ? bullet[1] : numbered[2];
      blocks.push(
        <View key={key} style={styles.listRow}>
          <Text variant="bodyLarge" style={[styles.marker, { color: theme.colors.onSurfaceVariant }]}>
            {marker}
          </Text>
          <Text variant="bodyLarge" style={styles.listText}>
            {renderInline(content, theme)}
            {tail}
          </Text>
        </View>,
      );
      return;
    }
    blocks.push(
      <Text key={key} variant="bodyLarge" style={styles.paragraph}>
        {renderInline(trimmed, theme)}
        {tail}
      </Text>,
    );
  });

  return <View>{blocks}</View>;
}

/** **pogrubienie**, *kursywa*, `kod` w obrębie linii (eksport do testów). */
export function tokenizeInline(text) {
  const tokens = [];
  const pattern = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*\s][^*]*\*)/g;
  let last = 0;
  let match;
  while ((match = pattern.exec(text)) !== null) {
    if (match.index > last) tokens.push({ type: 'text', value: text.slice(last, match.index) });
    const raw = match[0];
    if (raw.startsWith('**')) tokens.push({ type: 'bold', value: raw.slice(2, -2) });
    else if (raw.startsWith('`')) tokens.push({ type: 'code', value: raw.slice(1, -1) });
    else tokens.push({ type: 'italic', value: raw.slice(1, -1) });
    last = match.index + raw.length;
  }
  if (last < text.length) tokens.push({ type: 'text', value: text.slice(last) });
  return tokens;
}

function renderInline(text, theme) {
  return tokenizeInline(text).map((t, i) => {
    switch (t.type) {
      case 'bold':
        return (
          <Text key={i} style={styles.bold}>
            {t.value}
          </Text>
        );
      case 'italic':
        return (
          <Text key={i} style={styles.italic}>
            {t.value}
          </Text>
        );
      case 'code':
        return (
          <Text key={i} style={[styles.code, { backgroundColor: theme.colors.surfaceVariant }]}>
            {t.value}
          </Text>
        );
      default:
        return t.value;
    }
  });
}

const styles = StyleSheet.create({
  gap: { height: 8 },
  divider: { marginVertical: 12 },
  heading: { marginTop: 14, marginBottom: 6 },
  h2: { fontSize: 18 },
  paragraph: { lineHeight: 24, marginBottom: 2 },
  listRow: { flexDirection: 'row', marginBottom: 4, paddingRight: 8 },
  marker: { width: 24, lineHeight: 24 },
  listText: { flex: 1, lineHeight: 24 },
  bold: { fontFamily: 'Inter_600SemiBold' },
  italic: { fontStyle: 'italic' },
  code: { fontFamily: 'monospace', fontSize: 14 },
});
