import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import * as Haptics from 'expo-haptics';
import { Pressable, StyleSheet, View } from 'react-native';
import { Text, useTheme } from 'react-native-paper';

/** Duży przycisk akcji w stylu Gemini (ikona w kółku + tytuł + opis). */
export default function ActionCard({ icon, title, subtitle, onPress, primary = false, disabled = false }) {
  const theme = useTheme();
  const c = theme.custom;
  const bg = primary ? c.text : c.surfaceAlt;
  const fg = primary ? c.background : c.text;
  const sub = primary ? c.border : c.muted;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      disabled={disabled}
      onPress={() => {
        Haptics.selectionAsync().catch(() => {});
        onPress?.();
      }}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: bg, borderColor: primary ? bg : c.border, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.iconWrap, { backgroundColor: primary ? c.background : c.background }]}>
        <MaterialCommunityIcons name={icon} size={24} color={primary ? c.text : c.text} />
      </View>
      <View style={styles.texts}>
        <Text variant="titleMedium" style={{ color: fg }}>
          {title}
        </Text>
        {subtitle ? (
          <Text variant="bodySmall" style={{ color: sub, marginTop: 2 }}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      <MaterialCommunityIcons name="arrow-right" size={20} color={fg} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 18,
    borderRadius: 28,
    borderWidth: 1,
  },
  pressed: { transform: [{ scale: 0.985 }] },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  texts: { flex: 1 },
});
