import { StyleSheet, View } from 'react-native';
import { Chip, useTheme } from 'react-native-paper';

const TYPE_ICONS = {
  sprawdzian: 'file-document-edit-outline',
  kartkowka: 'note-edit-outline',
  notatka: 'notebook-outline',
  praca_domowa: 'home-edit-outline',
  inne: 'file-outline',
};

/** Typ dokumentu, przedmiot i pewność klasyfikacji. */
export default function ClassificationBadges({ classification, source, fromCache }) {
  const theme = useTheme();
  if (!classification && !source) return null;
  const chipStyle = [styles.chip, { backgroundColor: theme.colors.surfaceVariant }];

  return (
    <View style={styles.row}>
      {classification ? (
        <>
          <Chip compact icon={TYPE_ICONS[classification.type] || 'file-outline'} style={chipStyle}>
            {classification.typeLabel}
          </Chip>
          {classification.subject && classification.subject !== 'nieznany' ? (
            <Chip compact icon="school-outline" style={chipStyle}>
              {capitalize(classification.subject)}
            </Chip>
          ) : null}
          <Chip compact icon="gauge" style={chipStyle}>
            {`${Math.round(classification.confidence * 100)}%`}
          </Chip>
        </>
      ) : null}
      {source ? (
        <Chip compact icon={source === 'ocr' ? 'text-recognition' : 'image-outline'} style={chipStyle}>
          {source === 'ocr' ? 'Tekst (OCR)' : 'Zdjęcie'}
        </Chip>
      ) : null}
      {fromCache ? (
        <Chip compact icon="history" style={chipStyle}>
          Z pamięci
        </Chip>
      ) : null}
    </View>
  );
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  chip: { borderRadius: 999 },
});
