import { tokenizeInline } from '../components/Markdown';
import { formatDate } from '../components/HistoryItem';
import { isTextUsable } from '../services/ocrService';
import { estimateImageTokens, fitWithin } from '../utils/imageUtils';
import { normalizeType, parseClaudeResponse } from '../utils/responseParser';
import { SSEParser } from '../utils/sse';
import { createJsDecoder } from '../utils/utf8';

// Przykładowy strumień z dokumentacji Claude (streaming).
const DOC_STREAM = `event: message_start
data: {"type": "message_start", "message": {"id": "msg_1", "type": "message", "role": "assistant", "content": [], "model": "claude-sonnet-5-5", "stop_reason": null, "stop_sequence": null, "usage": {"input_tokens": 25, "output_tokens": 1}}}

event: content_block_start
data: {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}}

event: ping
data: {"type": "ping"}

event: content_block_delta
data: {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Hello"}}

event: content_block_delta
data: {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "!"}}

event: content_block_stop
data: {"type": "content_block_stop", "index": 0}

event: message_delta
data: {"type": "message_delta", "delta": {"stop_reason": "end_turn", "stop_sequence":null}, "usage": {"output_tokens": 15}}

event: message_stop
data: {"type": "message_stop"}

`;

describe('SSEParser', () => {
  test('parsuje przykładowy strumień z dokumentacji', () => {
    const events = new SSEParser().push(DOC_STREAM);
    expect(events.map((e) => e.event)).toEqual([
      'message_start',
      'content_block_start',
      'ping',
      'content_block_delta',
      'content_block_delta',
      'content_block_stop',
      'message_delta',
      'message_stop',
    ]);
    expect(JSON.parse(events[3].data).delta.text).toBe('Hello');
  });

  test('składa zdarzenia pocięte w dowolnych miejscach i z CRLF', () => {
    const crlf = DOC_STREAM.replace(/\n/g, '\r\n');
    for (const size of [1, 3, 7, 50]) {
      const parser = new SSEParser();
      const events = [];
      for (let i = 0; i < crlf.length; i += size) events.push(...parser.push(crlf.slice(i, i + size)));
      events.push(...parser.flush());
      expect(events).toHaveLength(8);
      expect(JSON.parse(events[4].data).delta.text).toBe('!');
    }
  });

  test('ignoruje komentarze i zwraca zdarzenie bez pustej linii na końcu (flush)', () => {
    const parser = new SSEParser();
    expect(parser.push(': keep-alive\n\n')).toEqual([]);
    expect(parser.push('event: x\ndata: {"a":1}')).toEqual([]);
    expect(parser.flush()).toEqual([{ event: 'x', data: '{"a":1}' }]);
  });
});

describe('dekoder UTF-8', () => {
  test('składa polskie znaki rozcięte między fragmentami', () => {
    const bytes = Array.from(Buffer.from('Zażółć gęślą jaźń 😀', 'utf8'));
    for (let cut = 1; cut < bytes.length; cut++) {
      const d = createJsDecoder();
      const out = d.decode(Uint8Array.from(bytes.slice(0, cut))) + d.decode(Uint8Array.from(bytes.slice(cut))) + d.end();
      expect(out).toBe('Zażółć gęślą jaźń 😀');
    }
  });
});

describe('parseClaudeResponse', () => {
  const full = '{"type":"sprawdzian","subject":"Matematyka","confidence":0.93,"need_image":false}\n---\n## Zadanie 1\n**Odpowiedź: B. 12**';

  test('rozdziela klasyfikację i odpowiedź', () => {
    const r = parseClaudeResponse(full, { complete: true });
    expect(r.classification).toEqual({
      type: 'sprawdzian',
      typeLabel: 'Sprawdzian',
      subject: 'matematyka',
      confidence: 0.93,
      needImage: false,
    });
    expect(r.answer).toBe('## Zadanie 1\n**Odpowiedź: B. 12**');
  });

  test('w trakcie streamingu czeka na koniec linii nagłówka', () => {
    const r = parseClaudeResponse('{"type":"notatka","subj');
    expect(r.headerComplete).toBe(false);
    expect(r.answer).toBe('');
    const r2 = parseClaudeResponse('{"type":"notatka","subject":"biologia","confidence":0.8}\n---\n## Stres');
    expect(r2.classification.typeLabel).toBe('Notatka');
    expect(r2.answer).toBe('## Stres');
  });

  test('prośba o zdjęcie (need_image)', () => {
    const r = parseClaudeResponse('{"type":"inne","subject":"nieznany","confidence":0,"need_image":true}', {
      complete: true,
    });
    expect(r.needImage).toBe(true);
    expect(r.answer).toBe('');
  });

  test('JSON w bloku kodu i brak nagłówka', () => {
    const fenced = '```json\n{"type":"kartkówka","subject":"fizyka","confidence":1.4}\n```\n---\nTreść';
    const r = parseClaudeResponse(fenced, { complete: true });
    expect(r.classification.type).toBe('kartkowka');
    expect(r.classification.confidence).toBe(1);
    expect(r.answer).toBe('Treść');

    const plain = parseClaudeResponse('Po prostu odpowiedź', { complete: true });
    expect(plain.classification).toBeNull();
    expect(plain.answer).toBe('Po prostu odpowiedź');
  });

  test('normalizacja typów', () => {
    expect(normalizeType('Praca domowa')).toBe('praca_domowa');
    expect(normalizeType('KARTKÓWKA')).toBe('kartkowka');
    expect(normalizeType('test')).toBe('sprawdzian');
    expect(normalizeType('coś innego')).toBe('inne');
  });
});

describe('pomocnicze', () => {
  test('isTextUsable odrzuca krótki i zaszumiony tekst', () => {
    expect(isTextUsable('')).toBe(false);
    expect(isTextUsable('Zad 1')).toBe(false);
    expect(isTextUsable('|| ;; ## ~~ 12 34 56 78 90 ++ -- == ** && %% $$ ##')).toBe(false);
    expect(isTextUsable('Zadanie 1. Ile wynosi 15% liczby 80? A. 8 B. 12 C. 15 D. 20')).toBe(true);
  });

  test('fitWithin zachowuje proporcje i limity', () => {
    expect(fitWithin(4000, 3000)).toEqual({ width: 1024, height: 768 });
    expect(fitWithin(3000, 4000)).toEqual({ width: 1024, height: 1365 });
    expect(fitWithin(1000, 4000)).toEqual({ width: 392, height: 1568 });
    expect(fitWithin(800, 600)).toEqual({ width: 800, height: 600 });
    expect(estimateImageTokens(1000, 1000)).toBe(1296); // przykład z dokumentacji Claude
  });

  test('tokenizeInline i formatDate', () => {
    expect(tokenizeInline('a **b** `c` *d*')).toEqual([
      { type: 'text', value: 'a ' },
      { type: 'bold', value: 'b' },
      { type: 'text', value: ' ' },
      { type: 'code', value: 'c' },
      { type: 'text', value: ' ' },
      { type: 'italic', value: 'd' },
    ]);
    expect(formatDate(new Date(2026, 9, 11, 9, 5).toISOString())).toBe('11.10.2026, 09:05');
  });
});
