import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react-native';
import { PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import HistoryScreen from '../screens/HistoryScreen';
import HomeScreen from '../screens/HomeScreen';
import ResultScreen from '../screens/ResultScreen';
import SettingsScreen from '../screens/SettingsScreen';
import WelcomeScreen from '../screens/WelcomeScreen';
import { darkTheme, lightTheme } from '../theme';

jest.mock('expo-secure-store', () => ({
  getItemAsync: jest.fn(async () => null),
  setItemAsync: jest.fn(async () => {}),
  deleteItemAsync: jest.fn(async () => {}),
}));

const SCAN = {
  id: 'scan-1',
  createdAt: '2026-10-11T09:05:00.000Z',
  imageUri: 'file:///scans/scan-1.jpg',
  classification: { type: 'sprawdzian', typeLabel: 'Sprawdzian', subject: 'matematyka', confidence: 0.9 },
  answer: '## Zadanie 1\nRozwiązanie: 0,15 · 80 = 12\n**Odpowiedź: B. 12**',
  source: 'ocr',
  ocrMs: 30,
  model: 'claude-sonnet-5-5',
  usage: { cache_read_input_tokens: 700 },
};

const Stack = createNativeStackNavigator();
const Empty = () => null;

async function renderScreen(name, component, params, theme = lightTheme) {
  return await render(
    <SafeAreaProvider initialMetrics={{ frame: { x: 0, y: 0, width: 390, height: 844 }, insets: { top: 0, left: 0, right: 0, bottom: 0 } }}>
      <PaperProvider theme={theme}>
        <NavigationContainer>
          <Stack.Navigator>
            <Stack.Screen name={name} component={component} initialParams={params} />
            {['Home', 'Result', 'History', 'Settings', 'Welcome']
              .filter((n) => n !== name)
              .map((n) => (
                <Stack.Screen key={n} name={n} component={Empty} />
              ))}
          </Stack.Navigator>
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>,
  );
}

beforeEach(async () => {
  await AsyncStorage.clear();
});

test('ekran powitalny', async () => {
  await renderScreen('Welcome', WelcomeScreen);
  expect(await screen.findByText('Skaner Dokumentów AI')).toBeTruthy();
  expect(screen.getByText('Zaczynamy')).toBeTruthy();
});

test('ekran główny: przyciski, baner klucza API i ostatnie skany', async () => {
  await AsyncStorage.setItem('history:v1', JSON.stringify([SCAN]));
  await renderScreen('Home', HomeScreen, undefined, darkTheme);
  expect(await screen.findByText('Zrób zdjęcie')).toBeTruthy();
  expect(screen.getByText('Wybierz z galerii')).toBeTruthy();
  expect(await screen.findByText('Dodaj klucz API Claude')).toBeTruthy();
  expect(await screen.findByText('Ostatnie skany')).toBeTruthy();
  expect(screen.getByText('Sprawdzian · matematyka')).toBeTruthy();
});

test('wynik z historii: klasyfikacja i odpowiedź bez ponownego wysyłania', async () => {
  await AsyncStorage.setItem('history:v1', JSON.stringify([SCAN]));
  await renderScreen('Result', ResultScreen, { scanId: 'scan-1' });
  expect(await screen.findByText('Sprawdzian')).toBeTruthy();
  expect(screen.getByText('Matematyka')).toBeTruthy();
  expect(screen.getByText('90%')).toBeTruthy();
  expect(await screen.findByText('Odpowiedź: B. 12')).toBeTruthy();
  expect(screen.getByText(/instrukcje z cache: 700/)).toBeTruthy();
});

test('wynik bez klucza API pokazuje komunikat i przycisk do ustawień', async () => {
  jest.useFakeTimers({ doNotFake: ['nextTick', 'setImmediate'] });
  const scanService = require('../services/scanService');
  const spy = jest
    .spyOn(scanService, 'scanDocument')
    .mockRejectedValue(new Error('Brak klucza API Claude. Dodaj go w Ustawieniach (ikona koła zębatego).'));
  await renderScreen('Result', ResultScreen, { imageUri: 'file:///photo.jpg', width: 3000, height: 4000 });
  expect(await screen.findByText('Coś poszło nie tak')).toBeTruthy();
  expect(screen.getByText('Ustawienia')).toBeTruthy();
  spy.mockRestore();
  jest.useRealTimers();
});

test('historia: lista i pusty stan', async () => {
  const view = await renderScreen('History', HistoryScreen);
  expect(await screen.findByText('Brak skanów')).toBeTruthy();
  await view.unmount();
  await AsyncStorage.setItem('history:v1', JSON.stringify([SCAN]));
  await renderScreen('History', HistoryScreen);
  expect(await screen.findByText('Sprawdzian · matematyka')).toBeTruthy();
});

test('ustawienia: walidacja klucza i wybór modelu', async () => {
  await renderScreen('Settings', SettingsScreen);
  expect(await screen.findByText(/Brak — dodaj klucz poniżej/)).toBeTruthy();
  const input = screen.getByTestId('api-key-input');
  await fireEvent.changeText(input, 'zly-klucz');
  expect(screen.getByText(/nie wygląda na klucz Claude/)).toBeTruthy();
  await fireEvent.changeText(input, 'sk-ant-api03-abcdefghijklmnopqrstuvwxyz');
  await waitFor(() => expect(screen.queryByText(/nie wygląda na klucz Claude/)).toBeNull());
  expect(screen.getByText(/Sonnet 5.5/)).toBeTruthy();
  expect(screen.getByText(/ML Kit nie jest dostępny/)).toBeTruthy();
  await act(async () => {});
});
