import { ClaudeError, buildHeaders, buildRequestBody, streamMessage } from '../services/claudeService';
import { SYSTEM_PROMPT } from '../services/prompts';
import { scanDocument } from '../services/scanService';

const direct = { mode: 'direct', url: 'https://api.anthropic.com/v1/messages', apiKey: 'sk-ant-test', model: 'claude-sonnet-5-5' };

/** Buduje strumień SSE z tekstem odpowiedzi, pocięty na fragmenty bajtów. */
function sseBytes(text, { chunk = 7, error } = {}) {
  const ev = (obj) => `event: ${obj.type}\ndata: ${JSON.stringify(obj)}\n\n`;
  let s = ev({ type: 'message_start', message: { model: 'claude-sonnet-5-5', usage: { input_tokens: 10, cache_read_input_tokens: 600 } } });
  s += ev({ type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } });
  for (const piece of text.match(/[\s\S]{1,5}/g) || []) {
    s += ev({ type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: piece } });
  }
  if (error) s += ev({ type: 'error', error });
  s += ev({ type: 'message_delta', delta: { stop_reason: 'end_turn' }, usage: { output_tokens: 42 } });
  s += ev({ type: 'message_stop' });
  const bytes = Buffer.from(s, 'utf8');
  const parts = [];
  for (let i = 0; i < bytes.length; i += chunk) parts.push(new Uint8Array(bytes.subarray(i, i + chunk)));
  return parts;
}

function okResponse(parts) {
  let i = 0;
  return {
    ok: true,
    status: 200,
    body: {
      getReader: () => ({
        read: async () => (i < parts.length ? { done: false, value: parts[i++] } : { done: true, value: undefined }),
      }),
    },
  };
}

function errorResponse(status, error) {
  return { ok: false, status, text: async () => JSON.stringify({ type: 'error', error }) };
}

describe('claudeService', () => {
  test('żądanie: streaming, prompt caching instrukcji, nagłówki', () => {
    const body = buildRequestBody({ model: 'claude-sonnet-5-5', content: [{ type: 'text', text: 'x' }] });
    expect(body.stream).toBe(true);
    expect(body.system[0]).toEqual({ type: 'text', text: SYSTEM_PROMPT, cache_control: { type: 'ephemeral' } });
    expect(buildHeaders(direct)).toMatchObject({ 'x-api-key': 'sk-ant-test', 'anthropic-version': '2023-06-01' });
    const proxyHeaders = buildHeaders({ mode: 'proxy', proxyToken: 'abc' });
    expect(proxyHeaders['x-api-key']).toBeUndefined();
    expect(proxyHeaders['x-app-token']).toBe('abc');
  });

  test('prompt systemowy jest dość długi dla prompt cachingu (≥ 512 tokenów)', () => {
    // Ostrożne oszacowanie dla polskiego tekstu: ~4 znaki na token.
    expect(SYSTEM_PROMPT.length / 4).toBeGreaterThan(512);
  });

  test('strumieniuje tekst z polskimi znakami pociętymi w środku bajtów', async () => {
    const text = 'Zażółć gęślą jaźń — odpowiedź: **B. 12**';
    const updates = [];
    const fetchImpl = jest.fn(async () => okResponse(sseBytes(text, { chunk: 3 })));
    const result = await streamMessage({ config: direct, content: [], fetchImpl, onText: (t) => updates.push(t) });
    expect(result.text).toBe(text);
    expect(result.stopReason).toBe('end_turn');
    expect(result.usage).toMatchObject({ cache_read_input_tokens: 600, output_tokens: 42 });
    expect(updates.length).toBeGreaterThan(3);
    expect(updates[updates.length - 1]).toBe(text);
    const [url, init] = fetchImpl.mock.calls[0];
    expect(url).toBe(direct.url);
    expect(JSON.parse(init.body).model).toBe('claude-sonnet-5-5');
  });

  test('błędy API → komunikaty po polsku; 529 ponawiane raz', async () => {
    await expect(
      streamMessage({
        config: direct,
        content: [],
        fetchImpl: async () => errorResponse(401, { type: 'authentication_error', message: 'invalid x-api-key' }),
      }),
    ).rejects.toThrow('Nieprawidłowy klucz API');

    const fetchImpl = jest
      .fn()
      .mockResolvedValueOnce(errorResponse(529, { type: 'overloaded_error', message: 'Overloaded' }))
      .mockResolvedValueOnce(okResponse(sseBytes('OK')));
    const r = await streamMessage({ config: direct, content: [], fetchImpl, retryDelayMs: 1 });
    expect(r.text).toBe('OK');
    expect(fetchImpl).toHaveBeenCalledTimes(2);

    await expect(
      streamMessage({
        config: direct,
        content: [],
        fetchImpl: async () =>
          errorResponse(400, { type: 'invalid_request_error', message: 'Your credit balance is too low' }),
      }),
    ).rejects.toThrow('Brak środków');
  });

  test('błąd w trakcie strumienia, brak sieci, brak klucza', async () => {
    await expect(
      streamMessage({
        config: direct,
        content: [],
        fetchImpl: async () => okResponse(sseBytes('Częś', { error: { type: 'overloaded_error', message: 'x' } })),
      }),
    ).rejects.toThrow('przeciążone');

    await expect(
      streamMessage({
        config: direct,
        content: [],
        maxRetries: 0,
        fetchImpl: async () => {
          throw new TypeError('Network request failed');
        },
      }),
    ).rejects.toThrow('Brak połączenia z internetem');

    await expect(streamMessage({ config: { mode: 'missing' }, content: [] })).rejects.toBeInstanceOf(ClaudeError);
  });
});

describe('scanService', () => {
  const HEADER_OK = '{"type":"sprawdzian","subject":"matematyka","confidence":0.9,"need_image":false}\n---\n';
  const OCR_TEXT = 'Zadanie 1. Ile wynosi 15% liczby 80? A. 8 B. 12 C. 15 D. 20';

  function makeDeps(overrides = {}) {
    const calls = [];
    const saved = [];
    const deps = {
      prepare: async () => ({ uri: 'file:///small.jpg', width: 1024, height: 1365, base64: 'BASE64' }),
      hash: async () => 'hash-1',
      recognize: async () => ({ available: true, text: OCR_TEXT, lines: [], durationMs: 25 }),
      apiConfig: async () => direct,
      findCached: async () => null,
      save: async (scan) => {
        saved.push(scan);
        return { ...scan, id: 'id-1' };
      },
      stream: async ({ content, onText }) => {
        calls.push(content);
        const text = HEADER_OK + '## Zadanie 1\n**Odpowiedź: B. 12**';
        onText?.(text, text);
        return { text, stopReason: 'end_turn', usage: {}, model: 'claude-sonnet-5-5' };
      },
      ...overrides,
    };
    return { deps, calls, saved };
  }

  test('czytelny OCR → do Claude idzie sam tekst w JSON (bez obrazu)', async () => {
    const { deps, calls, saved } = makeDeps();
    const stages = [];
    const result = await scanDocument({ imageUri: 'file:///orig.jpg', onStage: (s) => stages.push(s), deps });
    expect(calls).toHaveLength(1);
    expect(calls[0].some((b) => b.type === 'image')).toBe(false);
    expect(calls[0][0].text).toContain('"tekst":"Zadanie 1.');
    expect(result.source).toBe('ocr');
    expect(result.classification.type).toBe('sprawdzian');
    expect(saved[0].hash).toBe('hash-1');
    expect(stages).toEqual(['preparing', 'ocr', 'sending-text', 'done']);
  });

  test('Claude prosi o zdjęcie → drugie zapytanie ze zdjęciem', async () => {
    let n = 0;
    const { deps, calls } = makeDeps({
      stream: async ({ content }) => {
        calls.push(content);
        n += 1;
        const text =
          n === 1
            ? '{"type":"inne","subject":"nieznany","confidence":0,"need_image":true}'
            : HEADER_OK + '**Odpowiedź: C**';
        return { text, stopReason: 'end_turn', usage: {} };
      },
    });
    const result = await scanDocument({ imageUri: 'file:///orig.jpg', deps });
    expect(calls).toHaveLength(2);
    expect(calls[1][0]).toEqual({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: 'BASE64' } });
    expect(result.source).toBe('image');
    expect(result.answer).toBe('**Odpowiedź: C**');
  });

  test('brak OCR (Expo Go) albo krótki tekst → od razu zdjęcie', async () => {
    for (const ocr of [
      { available: false, text: '', lines: [], durationMs: 0 },
      { available: true, text: 'Zad 1', lines: [], durationMs: 5 },
    ]) {
      const { deps, calls } = makeDeps({ recognize: async () => ocr });
      const result = await scanDocument({ imageUri: 'file:///orig.jpg', deps });
      expect(calls).toHaveLength(1);
      expect(calls[0][0].type).toBe('image');
      expect(result.source).toBe('image');
    }
  });

  test('to samo zdjęcie → wynik z pamięci podręcznej, bez zapytania do API', async () => {
    const { deps, calls } = makeDeps({ findCached: async () => ({ id: 'old', answer: 'zapisane' }) });
    const result = await scanDocument({ imageUri: 'file:///orig.jpg', deps });
    expect(calls).toHaveLength(0);
    expect(result).toMatchObject({ id: 'old', fromCache: true });
  });
});
