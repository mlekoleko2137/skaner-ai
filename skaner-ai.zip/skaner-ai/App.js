// Importy z podścieżek — do aplikacji trafiają tylko 3 używane grubości Inter.
import { Inter_400Regular } from '@expo-google-fonts/inter/400Regular';
import { Inter_500Medium } from '@expo-google-fonts/inter/500Medium';
import { Inter_600SemiBold } from '@expo-google-fonts/inter/600SemiBold';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useFonts } from 'expo-font';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { useColorScheme, View } from 'react-native';
import { PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import HistoryScreen from './screens/HistoryScreen';
import HomeScreen from './screens/HomeScreen';
import ResultScreen from './screens/ResultScreen';
import SettingsScreen from './screens/SettingsScreen';
import WelcomeScreen from './screens/WelcomeScreen';
import { hasSeenWelcome } from './services/settingsService';
import { darkTheme, lightTheme, navigationTheme } from './theme';

const Stack = createNativeStackNavigator();

/** Ikony Paper z @expo/vector-icons (działa w Expo Go i w buildach). */
const paperSettings = {
  icon: (props) => <MaterialCommunityIcons {...props} />,
};

export default function App() {
  const scheme = useColorScheme();
  const isDark = scheme === 'dark';
  const theme = isDark ? darkTheme : lightTheme;

  const [fontsLoaded] = useFonts({ Inter_400Regular, Inter_500Medium, Inter_600SemiBold });
  const [initialRoute, setInitialRoute] = useState(null);

  useEffect(() => {
    hasSeenWelcome()
      .then((seen) => setInitialRoute(seen ? 'Home' : 'Welcome'))
      .catch(() => setInitialRoute('Home'));
  }, []);

  if (!fontsLoaded || !initialRoute) {
    return <View style={{ flex: 1, backgroundColor: theme.colors.background }} />;
  }

  return (
    <SafeAreaProvider>
      <PaperProvider theme={theme} settings={paperSettings}>
        <NavigationContainer theme={navigationTheme(theme, isDark)}>
          <StatusBar style={isDark ? 'light' : 'dark'} />
          <Stack.Navigator
            initialRouteName={initialRoute}
            screenOptions={{
              headerShadowVisible: false,
              headerTitleStyle: { fontFamily: 'Inter_600SemiBold', fontSize: 17 },
              headerBackButtonDisplayMode: 'minimal',
              contentStyle: { backgroundColor: theme.colors.background },
              animation: 'slide_from_right',
            }}
          >
            <Stack.Screen
              name="Welcome"
              component={WelcomeScreen}
              options={{ headerShown: false, animation: 'fade' }}
            />
            <Stack.Screen
              name="Home"
              component={HomeScreen}
              options={{ title: '', animation: 'fade' }}
            />
            <Stack.Screen
              name="Result"
              component={ResultScreen}
              options={{ title: 'Odpowiedź', animation: 'fade_from_bottom' }}
            />
            <Stack.Screen name="History" component={HistoryScreen} options={{ title: 'Historia skanów' }} />
            <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Ustawienia' }} />
          </Stack.Navigator>
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>
  );
}
