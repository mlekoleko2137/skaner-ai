import { DarkTheme as NavDark, DefaultTheme as NavLight } from '@react-navigation/native';
import { MD3DarkTheme, MD3LightTheme, configureFonts } from 'react-native-paper';

/**
 * Monochromatyczny motyw w stylu Gemini — jasny i ciemny.
 * Kolory zgodnie z wymaganiami: tło #FFFFFF / #000000, tekst #000000 / #FFFFFF,
 * akcenty #333333 / #CCCCCC.
 */

// Czcionki Inter (ładowane w App.js przez @expo-google-fonts/inter).
const FONT = {
  regular: 'Inter_400Regular',
  medium: 'Inter_500Medium',
  semibold: 'Inter_600SemiBold',
};

const variantFont = (family) => ({ fontFamily: family, fontWeight: 'normal' });

const fonts = configureFonts({
  config: {
    displayLarge: variantFont(FONT.semibold),
    displayMedium: variantFont(FONT.semibold),
    displaySmall: variantFont(FONT.semibold),
    headlineLarge: variantFont(FONT.semibold),
    headlineMedium: variantFont(FONT.semibold),
    headlineSmall: variantFont(FONT.semibold),
    titleLarge: variantFont(FONT.semibold),
    titleMedium: variantFont(FONT.semibold),
    titleSmall: variantFont(FONT.medium),
    labelLarge: variantFont(FONT.medium),
    labelMedium: variantFont(FONT.medium),
    labelSmall: variantFont(FONT.medium),
    bodyLarge: variantFont(FONT.regular),
    bodyMedium: variantFont(FONT.regular),
    bodySmall: variantFont(FONT.regular),
    default: variantFont(FONT.regular),
  },
});

const light = {
  background: '#FFFFFF',
  text: '#000000',
  accent: '#333333',
  muted: '#6B6B6B',
  surface: '#FFFFFF',
  surfaceAlt: '#F3F3F3',
  border: '#E2E2E2',
};

const dark = {
  background: '#000000',
  text: '#FFFFFF',
  accent: '#CCCCCC',
  muted: '#8F8F8F',
  surface: '#0A0A0A',
  surfaceAlt: '#161616',
  border: '#2A2A2A',
};

function buildColors(base, p) {
  return {
    ...base.colors,
    primary: p.text,
    onPrimary: p.background,
    primaryContainer: p.surfaceAlt,
    onPrimaryContainer: p.text,
    secondary: p.accent,
    onSecondary: p.background,
    secondaryContainer: p.surfaceAlt,
    onSecondaryContainer: p.text,
    tertiary: p.accent,
    onTertiary: p.background,
    tertiaryContainer: p.surfaceAlt,
    onTertiaryContainer: p.text,
    background: p.background,
    onBackground: p.text,
    surface: p.surface,
    onSurface: p.text,
    surfaceVariant: p.surfaceAlt,
    onSurfaceVariant: p.muted,
    outline: p.accent,
    outlineVariant: p.border,
    error: p.text,
    onError: p.background,
    errorContainer: p.surfaceAlt,
    onErrorContainer: p.text,
    inverseSurface: p.text,
    inverseOnSurface: p.background,
    inversePrimary: p.background,
    elevation: {
      level0: 'transparent',
      level1: p.surface,
      level2: p.surfaceAlt,
      level3: p.surfaceAlt,
      level4: p.surfaceAlt,
      level5: p.surfaceAlt,
    },
  };
}

export const lightTheme = {
  ...MD3LightTheme,
  roundness: 5,
  fonts,
  colors: buildColors(MD3LightTheme, light),
  custom: light,
};

export const darkTheme = {
  ...MD3DarkTheme,
  roundness: 5,
  fonts,
  colors: buildColors(MD3DarkTheme, dark),
  custom: dark,
};

/** Motywy dla React Navigation dopasowane do Paper. */
export function navigationTheme(paperTheme, isDark) {
  const base = isDark ? NavDark : NavLight;
  const p = paperTheme.custom;
  return {
    ...base,
    colors: {
      ...base.colors,
      primary: p.text,
      background: p.background,
      card: p.background,
      text: p.text,
      border: p.border,
      notification: p.text,
    },
  };
}
