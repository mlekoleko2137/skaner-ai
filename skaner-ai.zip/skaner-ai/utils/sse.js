/**
 * Parser strumienia Server-Sent Events (SSE) zwracanego przez API Claude
 * przy `stream: true`.
 *
 * Fragmenty sieciowe mogą urywać się w dowolnym miejscu (nawet w środku
 * linii), dlatego parser buforuje tekst i oddaje tylko kompletne zdarzenia.
 *
 * Format zdarzenia:
 *   event: content_block_delta
 *   data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Cześć"}}
 *   <pusta linia>
 */
export class SSEParser {
  constructor() {
    this.buffer = '';
  }

  /**
   * Dodaje kolejny fragment tekstu i zwraca listę kompletnych zdarzeń
   * w postaci `{ event, data }` (data to surowy string).
   */
  push(chunk) {
    this.buffer += chunk.replace(/\r\n?/g, '\n');
    const events = [];
    let separator;
    while ((separator = this.buffer.indexOf('\n\n')) !== -1) {
      const rawEvent = this.buffer.slice(0, separator);
      this.buffer = this.buffer.slice(separator + 2);
      const parsed = parseEventBlock(rawEvent);
      if (parsed) events.push(parsed);
    }
    return events;
  }

  /** Zwraca zdarzenie pozostawione w buforze po zakończeniu strumienia. */
  flush() {
    const rest = this.buffer.trim();
    this.buffer = '';
    if (!rest) return [];
    const parsed = parseEventBlock(rest);
    return parsed ? [parsed] : [];
  }
}

function parseEventBlock(block) {
  let event = 'message';
  const dataLines = [];
  for (const line of block.split('\n')) {
    if (!line || line.startsWith(':')) continue; // komentarz / keep-alive
    const colon = line.indexOf(':');
    const field = colon === -1 ? line : line.slice(0, colon);
    let value = colon === -1 ? '' : line.slice(colon + 1);
    if (value.startsWith(' ')) value = value.slice(1);
    if (field === 'event') event = value;
    else if (field === 'data') dataLines.push(value);
  }
  if (dataLines.length === 0) return null;
  return { event, data: dataLines.join('\n') };
}
