/**
 * `fetch` z obsługą strumieniowania odpowiedzi.
 *
 * Standardowy fetch React Native nie udostępnia `response.body` jako strumienia,
 * więc odpowiedź Claude przyszłaby dopiero w całości. `expo/fetch` (wbudowany
 * w Expo, działa też w Expo Go) zwraca `body.getReader()` — tekst pojawia się
 * na ekranie od pierwszych słów.
 *
 * Osobny plik ułatwia podmianę w testach.
 */
export { fetch as streamingFetch } from 'expo/fetch';
