/**
 * Strumieniowy dekoder UTF-8.
 *
 * Fragmenty odpowiedzi sieciowej mogą rozciąć wielobajtowy znak (np. „ą”
 * to 2 bajty) na dwa kawałki. Dekoder trzyma niedokończoną sekwencję
 * do następnego fragmentu. Jeśli środowisko ma `TextDecoder`, używamy go
 * (tryb `stream: true` robi to samo), w przeciwnym razie — własnej implementacji.
 */
export function createUtf8Decoder() {
  if (typeof globalThis.TextDecoder === 'function') {
    try {
      const native = new globalThis.TextDecoder('utf-8');
      return {
        decode: (bytes) => native.decode(bytes, { stream: true }),
        end: () => native.decode(),
      };
    } catch {
      // przechodzimy do implementacji w JS
    }
  }
  return createJsDecoder();
}

/** Implementacja w czystym JS (eksportowana także do testów). */
export function createJsDecoder() {
  let pending = [];

  const decode = (bytes) => {
    const input = pending.length ? Uint8Array.from([...pending, ...bytes]) : bytes;
    pending = [];
    let out = '';
    let i = 0;
    while (i < input.length) {
      const b = input[i];
      let needed = 0;
      let code = 0;
      if (b < 0x80) {
        out += String.fromCharCode(b);
        i += 1;
        continue;
      } else if ((b & 0xe0) === 0xc0) {
        needed = 1;
        code = b & 0x1f;
      } else if ((b & 0xf0) === 0xe0) {
        needed = 2;
        code = b & 0x0f;
      } else if ((b & 0xf8) === 0xf0) {
        needed = 3;
        code = b & 0x07;
      } else {
        out += '�';
        i += 1;
        continue;
      }
      if (i + needed >= input.length) {
        // Sekwencja urwana na końcu fragmentu — dokończymy ją przy następnym.
        pending = Array.from(input.slice(i));
        break;
      }
      let valid = true;
      for (let k = 1; k <= needed; k++) {
        const c = input[i + k];
        if ((c & 0xc0) !== 0x80) {
          valid = false;
          break;
        }
        code = (code << 6) | (c & 0x3f);
      }
      if (!valid) {
        out += '�';
        i += 1;
        continue;
      }
      out += String.fromCodePoint(code);
      i += needed + 1;
    }
    return out;
  };

  const end = () => {
    const rest = pending.length ? '�' : '';
    pending = [];
    return rest;
  };

  return { decode, end };
}
