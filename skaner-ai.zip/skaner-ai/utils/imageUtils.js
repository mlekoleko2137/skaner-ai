import * as Crypto from 'expo-crypto';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';

/**
 * Przygotowanie zdjęć przed wysłaniem do Claude.
 *
 * Mniejszy obraz = mniej tokenów = szybsza i tańsza odpowiedź. Claude liczy
 * obraz w kafelkach 28×28 px (tokeny ≈ ⌈szer/28⌉ × ⌈wys/28⌉), więc zdjęcie
 * 4000×3000 px zostałoby i tak zmniejszone po stronie API — robimy to od razu
 * na telefonie i nie wysyłamy zbędnych megabajtów.
 */

export const MAX_WIDTH = 1024; // zgodnie z wymaganiami: maks. 1024 px szerokości
export const MAX_HEIGHT = 1568; // pion kartki A4 — limit „standard” Claude dla dłuższego boku
export const JPEG_QUALITY = 0.8;

/** Oblicza docelowy rozmiar z zachowaniem proporcji (eksport do testów). */
export function fitWithin(width, height, maxWidth = MAX_WIDTH, maxHeight = MAX_HEIGHT) {
  if (!width || !height) return { width: maxWidth, height: null };
  const scale = Math.min(1, maxWidth / width, maxHeight / height);
  return { width: Math.round(width * scale), height: Math.round(height * scale) };
}

/** Szacowana liczba tokenów obrazu wg wzoru z dokumentacji Claude. */
export function estimateImageTokens(width, height) {
  return Math.ceil(width / 28) * Math.ceil(height / 28);
}

/**
 * Zmniejsza i kompresuje zdjęcie do JPEG.
 * @returns {Promise<{ uri: string, width: number, height: number, base64: string }>}
 */
export async function prepareImage(uri, sourceWidth, sourceHeight) {
  const target = fitWithin(sourceWidth, sourceHeight);
  const context = ImageManipulator.manipulate(uri);
  if (!sourceWidth || target.width < sourceWidth) {
    context.resize({ width: target.width, height: target.height });
  }
  const image = await context.renderAsync();
  const result = await image.saveAsync({
    format: SaveFormat.JPEG,
    compress: JPEG_QUALITY,
    base64: true,
  });
  if (!result.base64) throw new Error('Nie udało się przygotować zdjęcia.');
  return { uri: result.uri, width: result.width, height: result.height, base64: result.base64 };
}

/** Odcisk (SHA-256) zdjęcia — klucz pamięci podręcznej wyników. */
export async function hashImage(base64) {
  return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, base64);
}
