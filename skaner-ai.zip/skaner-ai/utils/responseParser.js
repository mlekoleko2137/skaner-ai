import { DOCUMENT_TYPES } from '../services/prompts';

/**
 * Rozbiera odpowiedź Claude (także niepełną — w trakcie streamingu) na:
 * - klasyfikację z pierwszej linii (JSON),
 * - treść odpowiedzi w Markdown (po linii `---`).
 *
 * Zwraca: { classification, answer, needImage, headerComplete }
 */
export function parseClaudeResponse(raw, { complete = false } = {}) {
  let text = (raw || '').replace(/\r\n?/g, '\n');

  // Model czasem opakowuje JSON w blok kodu — usuwamy go.
  text = text.replace(/^\s*```(?:json)?\s*\n/, '');

  const trimmedStart = text.replace(/^\s+/, '');
  if (!trimmedStart.startsWith('{')) {
    // Brak nagłówka JSON — całość traktujemy jako odpowiedź.
    if (!complete && trimmedStart.length < 2) {
      return { classification: null, answer: '', needImage: false, headerComplete: false };
    }
    return { classification: null, answer: trimmedStart.trim(), needImage: false, headerComplete: true };
  }

  const newline = trimmedStart.indexOf('\n');
  if (newline === -1 && !complete) {
    // Nagłówek jeszcze się nie skończył.
    return { classification: null, answer: '', needImage: false, headerComplete: false };
  }

  const headerLine = (newline === -1 ? trimmedStart : trimmedStart.slice(0, newline)).trim();
  let rest = newline === -1 ? '' : trimmedStart.slice(newline + 1);

  const classification = parseClassification(headerLine);
  if (!classification) {
    return { classification: null, answer: trimmedStart.trim(), needImage: false, headerComplete: true };
  }

  // Usuwamy zamknięcie bloku kodu i separator „---”.
  rest = rest.replace(/^\s*```\s*\n/, '').replace(/^\s*---+\s*(\n|$)/, '');

  return {
    classification,
    answer: rest.replace(/^\s+/, ''),
    needImage: classification.needImage,
    headerComplete: true,
  };
}

/** Parsuje i normalizuje JSON klasyfikacji. Zwraca null, gdy to nie JSON. */
export function parseClassification(line) {
  let data;
  try {
    data = JSON.parse(line.replace(/^```(?:json)?/, '').replace(/```$/, '').trim());
  } catch {
    return null;
  }
  if (!data || typeof data !== 'object') return null;
  const type = normalizeType(data.type);
  const subject =
    typeof data.subject === 'string' && data.subject.trim() ? data.subject.trim().toLowerCase() : 'nieznany';
  let confidence = Number(data.confidence);
  if (!Number.isFinite(confidence)) confidence = 0;
  confidence = Math.min(1, Math.max(0, confidence));
  return {
    type,
    typeLabel: DOCUMENT_TYPES[type],
    subject,
    confidence,
    needImage: data.need_image === true || data.needImage === true,
  };
}

/** „Kartkówka”, „praca domowa”, „PRACA_DOMOWA” → klucze z DOCUMENT_TYPES. */
export function normalizeType(value) {
  const v = String(value || '')
    .toLowerCase()
    .trim()
    .replace(/ó/g, 'o')
    .replace(/[\s-]+/g, '_');
  if (v in DOCUMENT_TYPES) return v;
  if (v.startsWith('sprawdz') || v === 'test' || v === 'praca_klasowa') return 'sprawdzian';
  if (v.startsWith('kartk')) return 'kartkowka';
  if (v.startsWith('notat')) return 'notatka';
  if (v.startsWith('praca_dom') || v.startsWith('zadanie_dom')) return 'praca_domowa';
  return 'inne';
}
