import * as ImagePicker from 'expo-image-picker';

/** Błąd uprawnień z komunikatem gotowym do pokazania. */
export class PermissionError extends Error {
  constructor(message) {
    super(message);
    this.name = 'PermissionError';
  }
}

const PICKER_OPTIONS = {
  mediaTypes: ['images'],
  quality: 1, // kompresujemy sami (imageUtils), tu bierzemy pełną jakość dla OCR
  allowsEditing: false,
  exif: false,
};

/**
 * Robi zdjęcie aparatem.
 * @returns {Promise<{ uri: string, width: number, height: number } | null>} null = anulowano
 */
export async function takePhoto() {
  const permission = await ImagePicker.requestCameraPermissionsAsync();
  if (!permission.granted) {
    throw new PermissionError(
      'Brak dostępu do aparatu. Włącz go w Ustawieniach telefonu → Skaner Dokumentów AI → Aparat.',
    );
  }
  return toAsset(await ImagePicker.launchCameraAsync(PICKER_OPTIONS));
}

/** Wybiera zdjęcie z galerii. */
export async function pickFromLibrary() {
  // Na Androidzie 13+ i iOS 14+ systemowy wybór zdjęć nie wymaga uprawnień,
  // ale prośba jest nieszkodliwa i pokrywa starsze wersje systemu.
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted && permission.accessPrivileges !== 'limited') {
    throw new PermissionError(
      'Brak dostępu do zdjęć. Włącz go w Ustawieniach telefonu → Skaner Dokumentów AI → Zdjęcia.',
    );
  }
  return toAsset(await ImagePicker.launchImageLibraryAsync(PICKER_OPTIONS));
}

function toAsset(result) {
  if (result.canceled || !result.assets?.length) return null;
  const { uri, width, height } = result.assets[0];
  return { uri, width, height };
}
