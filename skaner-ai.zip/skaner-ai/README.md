# Skaner Dokumentów AI

Aplikacja na iOS i Androida (React Native + Expo SDK 57): robisz zdjęcie sprawdzianu, kartkówki,
notatki albo pracy domowej, a Claude rozpoznaje typ dokumentu i odpowiada — tekst pojawia się na
bieżąco, słowo po słowie. Czarno-biały wygląd w stylu Gemini, tryb jasny i ciemny (wg ustawień
telefonu), historia skanów.

## Jak to działa

```
zdjęcie ──► zmniejszenie do 1024 px (JPEG) ──► odcisk SHA-256 ──► było już? ──► wynik z pamięci
                                                                     │ nie
                                                                     ▼
                         OCR na telefonie (Google ML Kit, offline, kilkadziesiąt ms)
                                                                     │
                         tekst czytelny? ── tak ──► JSON z tekstem ──► Claude (streaming)
                                │ nie                                      │
                                ▼                                          ▼ Claude: „potrzebuję obrazu”
                         zdjęcie ──► Claude Vision (streaming) ◄───────────┘
                                                                     │
                         1. linia: {"type","subject","confidence"}  →  znaczniki typu dokumentu
                         dalej: odpowiedź w Markdown                 →  efekt pisania
                                                                     │
                                                              zapis do historii
```

| Wymaganie | Gdzie w kodzie |
|---|---|
| OCR lokalnie (ML Kit), do Claude tylko tekst w JSON | `services/ocrService.js`, `services/prompts.js` → `buildOcrUserContent` |
| Zdjęcie do Claude Vision, gdy tekst nieczytelny | `services/scanService.js` (heurystyka `isTextUsable` + flaga `need_image` od Claude) |
| Klasyfikacja: sprawdzian / kartkówka / notatka / praca domowa / inne (JSON) | `services/prompts.js` → `SYSTEM_PROMPT`, `utils/responseParser.js` |
| Streaming (`stream: true`) | `services/claudeService.js` + `utils/sse.js` (przez `expo/fetch`) |
| Prompt caching instrukcji | `cache_control: { type: 'ephemeral' }` w `buildRequestBody` (prompt ma ~1000 tokenów, próg dla modeli 5.5 to 512) |
| Kompresja: JPEG, maks. 1024 px szerokości | `utils/imageUtils.js` |
| Cache wyników dla tych samych zdjęć | `services/historyService.js` → `findCachedScan` |
| Motyw monochromatyczny, Inter, react-native-paper | `theme.js` |
| Efekt „typing”, płynne przejścia | `hooks/useTypewriter.js`, `components/FadeIn.js`, animacje stosu nawigacji w `App.js` |
| Błędy: brak internetu, nieczytelny tekst, błędy API | `services/claudeService.js` → `errorFromPayload` (komunikaty po polsku, 1 automatyczna ponowna próba przy 429/529/5xx) |

## Struktura

```
App.js                      nawigacja (React Navigation), motyw, czcionki
theme.js                    jasny i ciemny motyw czarno-biały
screens/
  WelcomeScreen.js          ekran powitalny (przy pierwszym uruchomieniu)
  HomeScreen.js             „Zrób zdjęcie”, „Wybierz z galerii”, ostatnie skany
  ResultScreen.js           odpowiedź AI na żywo, klasyfikacja, kopiowanie, ponowna analiza
  HistoryScreen.js          historia skanów
  SettingsScreen.js         klucz API, model, status OCR, czyszczenie danych
services/
  claudeService.js          Messages API: streaming SSE, prompt caching, błędy
  ocrService.js             Google ML Kit (gdy dostępny)
  scanService.js            cały przepływ skanu (OCR → tekst / zdjęcie → zapis)
  prompts.js                prompt systemowy i treść wiadomości
  historyService.js         historia + pamięć podręczna wyników
  settingsService.js        klucz API (bezpieczny magazyn), model, konfiguracja
utils/
  imageUtils.js             kompresja, odcisk zdjęcia
  sse.js, utf8.js           parser strumienia i dekoder polskich znaków
  responseParser.js         klasyfikacja JSON + odpowiedź Markdown
  pickImage.js              aparat i galeria (z obsługą uprawnień)
components/                 Markdown, przyciski, znaczniki, wiersz historii, logo
proxy/worker.js             opcjonalny serwer pośredniczący (Cloudflare Worker)
__tests__/                  27 testów: parsowanie, streaming, przepływ skanu, ekrany
```

## Uruchomienie

Potrzebujesz: Node.js 20+ na komputerze (Windows wystarczy), iPhone z aplikacją **Expo Go**
z App Store, klucz API Claude.

```bash
cd skaner-ai
npm install
npm run go          # serwer deweloperski w trybie Expo Go
```

Na iPhonie otwórz aparat i zeskanuj kod QR z terminala — aplikacja otworzy się w Expo Go.
Telefon i komputer muszą być w tej samej sieci Wi-Fi. Jeśli się nie łączy (często przez zaporę
Windows), użyj: `npx expo start --go --tunnel`.

> Expo Go obsługuje tylko najnowsze SDK. Projekt jest na SDK 57. Jeśli Expo Go pokaże błąd
> niezgodnej wersji, zaktualizuj projekt: `npx expo install expo@latest`, a potem `npx expo install --fix`.

### Klucz API Claude — trzy sposoby

Klucz tworzysz w **Claude Console** (platform.claude.com) → API Keys. Konto API rozlicza się
osobno od subskrypcji claude.ai — trzeba doładować środki (Billing).

1. **W aplikacji (zalecane do testów i dla siebie).** Ustawienia (koło zębate) → wklej klucz →
   „Zapisz klucz”. Klucz trafia do Keychain (iOS) / Keystore (Android) przez `expo-secure-store`,
   nie ma go w kodzie aplikacji.
2. **Plik `.env`** — skopiuj `.env.example` jako `.env` i wpisz `EXPO_PUBLIC_ANTHROPIC_API_KEY=sk-ant-…`.
   Wygodne, ale klucz zostaje **wkompilowany w aplikację** i każdy, kto ma jej plik, może go
   wyciągnąć. Nie udostępniaj tak zbudowanej aplikacji. Po zmianie `.env` uruchom serwer ponownie.
3. **Serwer pośredniczący (gdy aplikację dostaną inne osoby).** Wdróż `proxy/worker.js` na
   Cloudflare Workers (instrukcja w komentarzu na górze pliku), a w `.env` ustaw
   `EXPO_PUBLIC_API_PROXY_URL` i `EXPO_PUBLIC_PROXY_TOKEN`. Klucz zostaje na serwerze, a worker
   przepuszcza tylko dozwolone modele i limit tokenów.

### OCR na telefonie (ML Kit) — wymaga własnego buildu

`@react-native-ml-kit/text-recognition` zawiera kod natywny, którego **nie ma w Expo Go**.
W Expo Go aplikacja działa w pełni, ale zamiast tekstu wysyła do Claude zdjęcie (Ustawienia
pokazują status OCR). Żeby włączyć OCR na telefonie, zbuduj własną wersję przez EAS — bez Maca:

```bash
npx eas-cli@latest login
npx eas-cli@latest build:configure                       # pierwszy raz
npx eas-cli@latest device:create                         # rejestracja iPhone'a (link otwierasz na telefonie)
npx eas-cli@latest build --profile development --platform ios
npm run dev                                              # serwer dla development buildu
```

Na iPhonie trzeba włączyć **Tryb dewelopera** (Ustawienia → Prywatność i ochrona → Tryb dewelopera).
Do instalacji na iPhonie wymagane jest płatne konto **Apple Developer Program** (99 USD/rok).
Na Androidzie development build zainstalujesz bez opłat: `--platform android`.

### iPhone bez komputera / TestFlight

- **EAS Build + Submit:** `npx eas-cli@latest build --profile production --platform ios --auto-submit`
  zbuduje aplikację w chmurze i wyśle do TestFlight. Wymaga konta Apple Developer.
- **Expo Launch** (launch.expo.dev, wersja beta): wrzucasz projekt na GitHub, w przeglądarce
  podajesz repozytorium i klikasz „Launch” — Expo konfiguruje build i wysyła aplikację do
  TestFlight. Działa też z telefonu. Konto Apple Developer nadal jest potrzebne do publikacji.
  Pamiętaj, żeby nie wrzucać pliku `.env` z kluczem do repozytorium (jest w `.gitignore`).
- **Feather** (instalator IPA na iPhonie) działa tylko z certyfikatem podpisującym. Używaj
  wyłącznie własnego certyfikatu Apple Developer — „udostępniane” certyfikaty z internetu
  naruszają zasady Apple i bywają unieważniane.

## Testy i kontrola jakości

```bash
npm test          # 27 testów (Jest + Testing Library)
npm run lint      # ESLint (konfiguracja Expo)
```

Testy obejmują: parser strumienia SSE (na przykładowym strumieniu z dokumentacji Claude, pocięty
w dowolnych miejscach), polskie znaki rozcięte między pakietami, parser klasyfikacji, mapowanie
błędów API i ponawianie, cały przepływ skanu (tekst vs zdjęcie, prośba Claude o obraz, pamięć
podręczna) oraz renderowanie wszystkich ekranów w trybie jasnym i ciemnym.

## Koszt i szybkość (orientacyjnie)

- Skan przez OCR: kilkaset tokenów tekstu zamiast ~1300–1900 tokenów obrazu, a instrukcje
  systemowe (~1000 tokenów) są czytane z cache przy kolejnych skanach w ciągu 5 minut.
- Model domyślny: **Claude Sonnet 5.5**. W Ustawieniach możesz przełączyć na **Haiku 5.5**
  (najszybszy, wielokrotnie tańszy) albo **Opus 5.5** (najdokładniejszy).
- Aktualne ceny: platform.claude.com → Pricing.

## Ograniczenia

- AI może się mylić — aplikacja pokazuje rozwiązanie krok po kroku, żeby dało się to sprawdzić.
- Odpowiedzi ponad 4096 tokenów są ucinane (aplikacja to sygnalizuje) — przy bardzo długich
  sprawdzianach zrób zdjęcie połowy kartki.
- Używaj aplikacji do nauki i sprawdzania własnych odpowiedzi, a nie w trakcie sprawdzianu.
