/**
 * Serwer pośredniczący (Cloudflare Worker) — klucz API Claude zostaje na
 * serwerze, a aplikacja zna tylko adres workera.
 *
 * Wdrożenie (darmowy plan Cloudflare wystarczy):
 *   npm create cloudflare@latest skaner-proxy   (szablon „Hello World” Worker)
 *   skopiuj ten plik jako src/index.js
 *   npx wrangler secret put ANTHROPIC_API_KEY   (wklej klucz sk-ant-…)
 *   npx wrangler secret put APP_TOKEN           (dowolny długi losowy ciąg)
 *   npx wrangler deploy
 * Potem w .env aplikacji:
 *   EXPO_PUBLIC_API_PROXY_URL=https://skaner-proxy.<twoje-konto>.workers.dev
 *   EXPO_PUBLIC_PROXY_TOKEN=<ten sam APP_TOKEN>
 *
 * Worker przepuszcza tylko dozwolone modele i ogranicza max_tokens, żeby
 * ktoś, kto wyciągnie adres z aplikacji, nie mógł go dowolnie nadużywać.
 */

const ALLOWED_MODELS = new Set(['claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5']);
const MAX_TOKENS_LIMIT = 4096;
const MAX_BODY_BYTES = 8 * 1024 * 1024;

export default {
  async fetch(request, env) {
    if (request.method !== 'POST') {
      return json({ error: { type: 'invalid_request_error', message: 'Only POST' } }, 405);
    }
    if (env.APP_TOKEN && request.headers.get('x-app-token') !== env.APP_TOKEN) {
      return json({ error: { type: 'authentication_error', message: 'Bad app token' } }, 401);
    }
    const length = Number(request.headers.get('content-length') || 0);
    if (length > MAX_BODY_BYTES) {
      return json({ error: { type: 'request_too_large', message: 'Body too large' } }, 413);
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: { type: 'invalid_request_error', message: 'Invalid JSON' } }, 400);
    }
    if (!ALLOWED_MODELS.has(body.model)) {
      return json({ error: { type: 'invalid_request_error', message: 'Model not allowed' } }, 400);
    }
    body.max_tokens = Math.min(Number(body.max_tokens) || 1024, MAX_TOKENS_LIMIT);

    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': env.ANTHROPIC_API_KEY,
        'anthropic-version': request.headers.get('anthropic-version') || '2023-06-01',
      },
      body: JSON.stringify(body),
    });

    // Strumień SSE przekazujemy bez buforowania.
    return new Response(upstream.body, {
      status: upstream.status,
      headers: {
        'content-type': upstream.headers.get('content-type') || 'application/json',
        'cache-control': 'no-cache',
      },
    });
  },
};

function json(data, status) {
  return new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });
}
