import { prepareImage, hashImage } from '../utils/imageUtils';
import { parseClaudeResponse } from '../utils/responseParser';
import { streamMessage as defaultStreamMessage } from './claudeService';
import { addScan, findCachedScan } from './historyService';
import { recognizeText as defaultRecognizeText, isTextUsable } from './ocrService';
import { buildImageUserContent, buildOcrUserContent } from './prompts';
import { getApiConfig } from './settingsService';

/**
 * Cały przepływ skanu:
 *
 *  1. zmniejszenie i kompresja zdjęcia (JPEG, maks. 1024 px szerokości),
 *  2. pamięć podręczna — to samo zdjęcie nie idzie drugi raz do API,
 *  3. OCR na urządzeniu (ML Kit, offline, kilkadziesiąt ms),
 *  4. tekst z OCR jako JSON → Claude (streaming),
 *  5. jeśli tekstu brak / jest nieczytelny albo Claude poprosi o obraz →
 *     wysyłamy zdjęcie (Claude Vision),
 *  6. zapis do historii.
 *
 * Etapy (onStage): 'preparing' | 'cache' | 'ocr' | 'sending-text' |
 *                  'sending-image' | 'done'
 */
export async function scanDocument({
  imageUri,
  width,
  height,
  forceImage = false,
  onStage,
  onUpdate,
  signal,
  // wstrzykiwane w testach:
  deps = {},
}) {
  const {
    prepare = prepareImage,
    hash = hashImage,
    recognize = defaultRecognizeText,
    stream = defaultStreamMessage,
    apiConfig = getApiConfig,
    findCached = findCachedScan,
    save = addScan,
  } = deps;

  onStage?.('preparing');
  const prepared = await prepare(imageUri, width, height);
  const imageHash = await hash(prepared.base64);

  if (!forceImage) {
    const cached = await findCached(imageHash);
    if (cached) {
      onStage?.('cache');
      return { ...cached, fromCache: true };
    }
  }

  const config = await apiConfig();

  // OCR na oryginale (pełna rozdzielczość = lepsze rozpoznawanie).
  let ocr = { available: false, text: '', lines: [], durationMs: 0 };
  if (!forceImage) {
    onStage?.('ocr');
    ocr = await recognize(imageUri);
  }

  const useText = !forceImage && ocr.available && isTextUsable(ocr.text);

  const run = async (source) => {
    const content =
      source === 'ocr'
        ? buildOcrUserContent(ocr.text)
        : buildImageUserContent(prepared.base64, ocr.text);
    onStage?.(source === 'ocr' ? 'sending-text' : 'sending-image');
    const result = await stream({
      config,
      content,
      signal,
      onText: (full) => {
        const parsed = parseClaudeResponse(full);
        // Gdy Claude prosi o obraz, nie pokazujemy tej odpowiedzi.
        if (!parsed.needImage) onUpdate?.({ ...parsed, source });
      },
    });
    return { result, parsed: parseClaudeResponse(result.text, { complete: true }) };
  };

  let source = useText ? 'ocr' : 'image';
  let { result, parsed } = await run(source);

  if (source === 'ocr' && (parsed.needImage || !parsed.answer.trim())) {
    // Claude uznał tekst za niewystarczający — wysyłamy zdjęcie.
    source = 'image';
    ({ result, parsed } = await run(source));
  }

  if (!parsed.answer.trim()) {
    throw new Error('Claude nie zwrócił treści odpowiedzi. Spróbuj ponownie.');
  }

  const scan = await save({
    imageUri: prepared.uri,
    hash: imageHash,
    classification: parsed.classification,
    answer: parsed.answer,
    source,
    ocrText: ocr.text,
    ocrAvailable: ocr.available,
    ocrMs: ocr.durationMs,
    model: result.model || config.model,
    usage: result.usage,
    truncated: result.stopReason === 'max_tokens',
  });
  onStage?.('done');
  return { ...scan, fromCache: false };
}
