import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';

/**
 * Ustawienia aplikacji i konfiguracja połączenia z API Claude.
 *
 * Skąd bierzemy klucz (w tej kolejności):
 * 1. Klucz wklejony w Ustawieniach aplikacji — trzymany w Keychain/Keystore
 *    (expo-secure-store), NIE trafia do kodu aplikacji.
 * 2. Zmienna EXPO_PUBLIC_ANTHROPIC_API_KEY z pliku .env — wygodne do testów,
 *    ale zostaje wkompilowana w aplikację (każdy, kto ma plik aplikacji,
 *    może ją odczytać). Nie publikuj tak zbudowanej aplikacji.
 * 3. Serwer pośredniczący (EXPO_PUBLIC_API_PROXY_URL) — klucz zostaje na
 *    serwerze. Zalecane, jeśli aplikację dostaną inne osoby.
 */

const API_KEY_STORE = 'anthropic_api_key';
const MODEL_KEY = 'settings:model';
const WELCOME_KEY = 'settings:welcomeSeen';

export const DEFAULT_MODEL = process.env.EXPO_PUBLIC_CLAUDE_MODEL || 'claude-sonnet-5-5';

/** Modele do wyboru w Ustawieniach (ID z dokumentacji Claude). */
export const MODELS = [
  { id: 'claude-sonnet-5-5', label: 'Sonnet 5.5', hint: 'Szybki i dokładny (zalecany)' },
  { id: 'claude-haiku-5-5', label: 'Haiku 5.5', hint: 'Najszybszy i najtańszy' },
  { id: 'claude-opus-5-5', label: 'Opus 5.5', hint: 'Najdokładniejszy, wolniejszy' },
];

const ENV_API_KEY = process.env.EXPO_PUBLIC_ANTHROPIC_API_KEY || '';
const ENV_PROXY_URL = process.env.EXPO_PUBLIC_API_PROXY_URL || '';
const ENV_PROXY_TOKEN = process.env.EXPO_PUBLIC_PROXY_TOKEN || '';

export async function getStoredApiKey() {
  try {
    return (await SecureStore.getItemAsync(API_KEY_STORE)) || '';
  } catch {
    return '';
  }
}

export async function saveApiKey(key) {
  const trimmed = (key || '').trim();
  if (!trimmed) {
    await SecureStore.deleteItemAsync(API_KEY_STORE);
    return;
  }
  await SecureStore.setItemAsync(API_KEY_STORE, trimmed);
}

export async function getModel() {
  const stored = await AsyncStorage.getItem(MODEL_KEY);
  return stored || DEFAULT_MODEL;
}

export async function setModel(id) {
  await AsyncStorage.setItem(MODEL_KEY, id);
}

export async function hasSeenWelcome() {
  return (await AsyncStorage.getItem(WELCOME_KEY)) === '1';
}

export async function markWelcomeSeen() {
  await AsyncStorage.setItem(WELCOME_KEY, '1');
}

/**
 * Zwraca konfigurację połączenia:
 * { mode: 'proxy' | 'direct' | 'missing', url, apiKey, proxyToken, model, keySource }
 */
export async function getApiConfig() {
  const model = await getModel();
  const storedKey = await getStoredApiKey();
  if (storedKey) {
    return { mode: 'direct', url: 'https://api.anthropic.com/v1/messages', apiKey: storedKey, model, keySource: 'app' };
  }
  if (ENV_PROXY_URL) {
    return { mode: 'proxy', url: ENV_PROXY_URL, proxyToken: ENV_PROXY_TOKEN, model, keySource: 'proxy' };
  }
  if (ENV_API_KEY) {
    return { mode: 'direct', url: 'https://api.anthropic.com/v1/messages', apiKey: ENV_API_KEY, model, keySource: 'env' };
  }
  return { mode: 'missing', model, keySource: 'none' };
}
