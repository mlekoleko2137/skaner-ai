import Constants from 'expo-constants';
import { NativeModules } from 'react-native';

/**
 * Lokalne rozpoznawanie tekstu (OCR) przez Google ML Kit.
 *
 * ML Kit to moduł natywny — NIE ma go w Expo Go. Działa w development
 * buildzie i w wersji produkcyjnej (EAS Build). W Expo Go funkcja zwraca
 * `available: false`, a aplikacja wysyła do Claude zdjęcie zamiast tekstu.
 */

let cachedModule; // undefined = jeszcze nie sprawdzano, null = niedostępny

function loadMlKit() {
  if (cachedModule !== undefined) return cachedModule;
  // W Expo Go nie próbujemy nawet ładować modułu natywnego.
  if (Constants.executionEnvironment === 'storeClient') {
    cachedModule = null;
    return cachedModule;
  }
  // Pakiet zawsze eksportuje `recognize`, ale bez dołączonego kodu natywnego
  // wywołanie rzuca błąd — dlatego sprawdzamy sam moduł natywny.
  if (!NativeModules.TextRecognition) {
    cachedModule = null;
    return cachedModule;
  }
  try {
    const mod = require('@react-native-ml-kit/text-recognition');
    cachedModule = mod?.default ?? mod;
    if (!cachedModule || typeof cachedModule.recognize !== 'function') cachedModule = null;
  } catch {
    cachedModule = null;
  }
  return cachedModule;
}

/** Czy OCR na urządzeniu jest dostępny w tej wersji aplikacji. */
export function isOcrAvailable() {
  return loadMlKit() !== null;
}

/**
 * Rozpoznaje tekst na zdjęciu.
 * @returns {Promise<{ available: boolean, text: string, lines: string[], durationMs: number, error?: string }>}
 */
export async function recognizeText(imageUri) {
  const mlkit = loadMlKit();
  if (!mlkit) return { available: false, text: '', lines: [], durationMs: 0 };

  const started = Date.now();
  try {
    const result = await mlkit.recognize(imageUri);
    const lines = [];
    for (const block of result?.blocks || []) {
      for (const line of block.lines || []) {
        if (line?.text) lines.push(line.text);
      }
    }
    const text = (result?.text || lines.join('\n')).trim();
    return { available: true, text, lines, durationMs: Date.now() - started };
  } catch (e) {
    return { available: true, text: '', lines: [], durationMs: Date.now() - started, error: String(e?.message || e) };
  }
}

/**
 * Czy tekst z OCR wystarczy, żeby wysłać sam tekst (bez zdjęcia).
 * Odrzucamy teksty bardzo krótkie albo „szum” (mało liter, dużo znaków
 * przypadkowych) — wtedy Claude dostanie zdjęcie.
 */
export function isTextUsable(text) {
  const t = (text || '').trim();
  if (t.length < 40) return false;
  const letters = (t.match(/[\p{L}]/gu) || []).length;
  const words = t.split(/\s+/).filter((w) => /[\p{L}\d]{2,}/u.test(w)).length;
  const nonSpace = t.replace(/\s/g, '').length || 1;
  return words >= 6 && letters / nonSpace >= 0.5;
}
