import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import { Directory, File, Paths } from 'expo-file-system';

/**
 * Historia skanów + pamięć podręczna wyników.
 *
 * - Lista skanów (bez obrazów) trzymana jest w AsyncStorage.
 * - Miniatura każdego skanu jest kopiowana do katalogu dokumentów aplikacji
 *   (pliki z cache systemowego mogą zniknąć).
 * - Pamięć podręczna: odcisk SHA-256 zdjęcia → id skanu. To samo zdjęcie
 *   wysłane ponownie nie trafia do API, tylko otwiera zapisany wynik.
 */

const HISTORY_KEY = 'history:v1';
const CACHE_KEY = 'resultCache:v1';
const MAX_ITEMS = 100;

function scansDir() {
  const dir = new Directory(Paths.document, 'scans');
  if (!dir.exists) dir.create({ intermediates: true, idempotent: true });
  return dir;
}

async function readJson(key, fallback) {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export async function getScans() {
  return readJson(HISTORY_KEY, []);
}

export async function getScan(id) {
  const scans = await getScans();
  return scans.find((s) => s.id === id) || null;
}

/**
 * Zapisuje skan. `scan` zawiera m.in. { imageUri, hash, classification,
 * answer, source, ocrText, model, usage }.
 */
export async function addScan(scan) {
  const id = Crypto.randomUUID();
  let imageUri = scan.imageUri;
  try {
    const dest = new File(scansDir(), `${id}.jpg`);
    await new File(scan.imageUri).copy(dest);
    imageUri = dest.uri;
  } catch {
    // Brak kopii miniatury nie blokuje zapisu wyniku.
  }
  const entry = { ...scan, id, imageUri, createdAt: new Date().toISOString() };
  const scans = [entry, ...(await getScans())];

  // Usuwamy najstarsze ponad limit (razem z miniaturami).
  const removed = scans.splice(MAX_ITEMS);
  removed.forEach(deleteImageQuietly);

  await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(scans));
  if (scan.hash) {
    const cache = await readJson(CACHE_KEY, {});
    cache[scan.hash] = id;
    await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  }
  return entry;
}

export async function deleteScan(id) {
  const scans = await getScans();
  const scan = scans.find((s) => s.id === id);
  if (scan) deleteImageQuietly(scan);
  await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(scans.filter((s) => s.id !== id)));
  const cache = await readJson(CACHE_KEY, {});
  for (const [hash, scanId] of Object.entries(cache)) if (scanId === id) delete cache[hash];
  await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(cache));
}

export async function clearHistory() {
  (await getScans()).forEach(deleteImageQuietly);
  await AsyncStorage.multiRemove([HISTORY_KEY, CACHE_KEY]);
}

/** Zwraca zapisany wynik dla tego samego zdjęcia albo null. */
export async function findCachedScan(hash) {
  if (!hash) return null;
  const cache = await readJson(CACHE_KEY, {});
  const id = cache[hash];
  return id ? getScan(id) : null;
}

function deleteImageQuietly(scan) {
  try {
    if (scan?.imageUri?.includes('/scans/')) {
      const file = new File(scan.imageUri);
      if (file.exists) file.delete();
    }
  } catch {
    // plik już nie istnieje
  }
}
