import { streamingFetch } from '../utils/http';
import { SSEParser } from '../utils/sse';
import { createUtf8Decoder } from '../utils/utf8';
import { SYSTEM_PROMPT } from './prompts';

/**
 * Klient Messages API Claude ze streamingiem (SSE).
 *
 * Używamy surowego HTTP zamiast @anthropic-ai/sdk: w React Native SDK
 * wymaga dodatkowych polyfilli strumieni, a tu potrzebujemy jednego
 * endpointu. Format żądań i zdarzeń jest zgodny z dokumentacją:
 * https://platform.claude.com/docs/en/build-with-claude/streaming
 */

export const ANTHROPIC_VERSION = '2023-06-01';
export const MAX_TOKENS = 4096;

export class ClaudeError extends Error {
  constructor(message, { status = 0, type = 'unknown', retryable = false, cause } = {}) {
    super(message);
    this.name = 'ClaudeError';
    this.status = status;
    this.type = type;
    this.retryable = retryable;
    this.cause = cause;
  }
}

/** Treść żądania. Instrukcje systemowe oznaczamy do prompt cachingu. */
export function buildRequestBody({ model, content, maxTokens = MAX_TOKENS }) {
  return {
    model,
    max_tokens: maxTokens,
    stream: true,
    system: [
      {
        type: 'text',
        text: SYSTEM_PROMPT,
        cache_control: { type: 'ephemeral' },
      },
    ],
    messages: [{ role: 'user', content }],
  };
}

export function buildHeaders(config) {
  const headers = {
    'content-type': 'application/json',
    accept: 'text/event-stream',
    'anthropic-version': ANTHROPIC_VERSION,
  };
  if (config.mode === 'direct') headers['x-api-key'] = config.apiKey;
  if (config.mode === 'proxy' && config.proxyToken) headers['x-app-token'] = config.proxyToken;
  return headers;
}

/**
 * Wysyła wiadomość i strumieniuje odpowiedź.
 *
 * @param {object} p
 * @param {object} p.config      wynik getApiConfig()
 * @param {Array}  p.content     bloki treści wiadomości użytkownika
 * @param {(fullText: string, delta: string) => void} [p.onText]
 * @param {AbortSignal} [p.signal]
 * @returns {Promise<{ text: string, stopReason: string|null, usage: object, model: string|null }>}
 */
export async function streamMessage({
  config,
  content,
  onText,
  signal,
  fetchImpl = streamingFetch,
  maxRetries = 1,
  retryDelayMs = 1500,
}) {
  if (!config || config.mode === 'missing') {
    throw new ClaudeError('Brak klucza API Claude. Dodaj go w Ustawieniach (ikona koła zębatego).', {
      type: 'no_api_key',
    });
  }
  const body = JSON.stringify(buildRequestBody({ model: config.model, content }));

  for (let attempt = 0; ; attempt++) {
    let response;
    try {
      response = await fetchImpl(config.url, {
        method: 'POST',
        headers: buildHeaders(config),
        body,
        signal,
      });
    } catch (e) {
      if (isAbort(e, signal)) throw abortError();
      throw new ClaudeError(
        'Brak połączenia z internetem. Sprawdź Wi-Fi lub dane komórkowe i spróbuj ponownie.',
        { type: 'network', retryable: true, cause: e },
      );
    }

    if (!response.ok) {
      const error = await errorFromResponse(response, config.model);
      if (error.retryable && attempt < maxRetries) {
        await delay(retryDelayMs * (attempt + 1), signal);
        continue;
      }
      throw error;
    }

    return readStream(response, { onText, signal });
  }
}

async function readStream(response, { onText, signal }) {
  const state = { text: '', stopReason: null, usage: {}, model: null };
  const parser = new SSEParser();
  const handle = (events) => {
    for (const ev of events) applyEvent(state, ev, onText);
  };

  // Gdyby środowisko nie dawało strumienia — czytamy całość naraz.
  if (!response.body || typeof response.body.getReader !== 'function') {
    const raw = await response.text();
    handle(parser.push(raw));
    handle(parser.flush());
    return finish(state);
  }

  const reader = response.body.getReader();
  const decoder = createUtf8Decoder();
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = typeof value === 'string' ? value : decoder.decode(value);
      handle(parser.push(chunk));
    }
    handle(parser.push(decoder.end()));
    handle(parser.flush());
  } catch (e) {
    if (e instanceof ClaudeError) throw e;
    if (isAbort(e, signal)) throw abortError();
    throw new ClaudeError('Połączenie zostało przerwane w trakcie odpowiedzi. Spróbuj ponownie.', {
      type: 'network',
      retryable: true,
      cause: e,
    });
  }
  return finish(state);
}

function finish(state) {
  if (!state.text && !state.stopReason) {
    throw new ClaudeError('Claude nie zwrócił odpowiedzi. Spróbuj ponownie.', { type: 'empty', retryable: true });
  }
  return state;
}

/** Obsługa pojedynczego zdarzenia SSE (eksport do testów). */
export function applyEvent(state, { data }, onText) {
  let payload;
  try {
    payload = JSON.parse(data);
  } catch {
    return; // nieznany format — ignorujemy, zgodnie z zaleceniem dokumentacji
  }
  switch (payload.type) {
    case 'message_start':
      state.model = payload.message?.model ?? null;
      state.usage = { ...(payload.message?.usage || {}) };
      break;
    case 'content_block_delta':
      if (payload.delta?.type === 'text_delta' && payload.delta.text) {
        state.text += payload.delta.text;
        onText?.(state.text, payload.delta.text);
      }
      break;
    case 'message_delta':
      state.stopReason = payload.delta?.stop_reason ?? state.stopReason;
      Object.assign(state.usage, payload.usage || {});
      break;
    case 'error':
      throw errorFromPayload(0, payload.error);
    default:
      break; // ping, content_block_start/stop, message_stop, przyszłe typy
  }
}

async function errorFromResponse(response, model) {
  let payload = null;
  try {
    payload = JSON.parse(await response.text());
  } catch {
    // treść nie jest JSON-em (np. błąd serwera pośredniczącego)
  }
  return errorFromPayload(response.status, payload?.error, model);
}

/** Zamienia błąd API na komunikat po polsku (eksport do testów). */
export function errorFromPayload(status, error, model) {
  const type = error?.type || statusToType(status);
  const apiMessage = error?.message || '';
  const make = (message, retryable = false) => new ClaudeError(message, { status, type, retryable });

  switch (type) {
    case 'authentication_error':
      return make('Nieprawidłowy klucz API. Sprawdź go w Ustawieniach.');
    case 'permission_error':
      return make('Ten klucz API nie ma dostępu do wybranego modelu. Zmień model w Ustawieniach.');
    case 'not_found_error':
      return make(`Model ${model ? `„${model}” ` : ''}jest niedostępny. Wybierz inny w Ustawieniach.`);
    case 'request_too_large':
      return make('Zdjęcie jest za duże. Spróbuj zrobić je jeszcze raz z mniejszej odległości.');
    case 'rate_limit_error':
      return make('Przekroczono limit zapytań do Claude. Odczekaj chwilę i spróbuj ponownie.', true);
    case 'overloaded_error':
      return make('Serwery Claude są teraz przeciążone. Spróbuj ponownie za kilka sekund.', true);
    case 'api_error':
      return make('Błąd po stronie Claude. Spróbuj ponownie.', true);
    case 'invalid_request_error':
      if (/credit|balance|billing/i.test(apiMessage)) {
        return make('Brak środków na koncie API. Doładuj je w Claude Console (Billing).');
      }
      return make(`Nieprawidłowe zapytanie: ${apiMessage || 'sprawdź ustawienia.'}`);
    default:
      return make(
        apiMessage ? `Błąd API (${status || '?'}): ${apiMessage}` : `Błąd połączenia z Claude (kod ${status || '?'}).`,
        status >= 500,
      );
  }
}

function statusToType(status) {
  return (
    {
      400: 'invalid_request_error',
      401: 'authentication_error',
      403: 'permission_error',
      404: 'not_found_error',
      413: 'request_too_large',
      429: 'rate_limit_error',
      500: 'api_error',
      529: 'overloaded_error',
    }[status] || 'unknown'
  );
}

function isAbort(e, signal) {
  return signal?.aborted || e?.name === 'AbortError';
}

function abortError() {
  return new ClaudeError('Anulowano.', { type: 'aborted' });
}

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener?.('abort', () => {
      clearTimeout(t);
      reject(abortError());
    });
  });
}
